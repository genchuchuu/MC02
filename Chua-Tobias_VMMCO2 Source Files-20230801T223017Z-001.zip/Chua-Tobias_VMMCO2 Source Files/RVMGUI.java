import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Map;

/**
 * The RVMGUI class represents the graphical user interface (GUI) for a Regular Vending Machine.
 * It extends the JFrame class and provides functionalities for both Test Features and Maintenance Features.
 *
 * @author Genelle Chua
 * @author Angela Tobias
 * @version 24.0
 */
public class RVMGUI extends JFrame {
    // Declare class attributes
    private RegularVendingMachine vendingMachine;
    private VendingMachineFactory mainFrame;

    /**
     * Constructs a new RVMGUI object with the given RegularVendingMachine and VendingMachineFactory.
     *
     * @param vendingMachine The RegularVendingMachine object to be controlled by the GUI.
     * @param mainFrame The VendingMachineFactory object representing the main frame of the application.
     */
    public RVMGUI(RegularVendingMachine vendingMachine, VendingMachineFactory mainFrame) {
        // Initialize the RegularVendingMachine and VendingMachineFactory objects
        this.vendingMachine = vendingMachine;
        this.mainFrame = mainFrame;
        // Set the title and size of the GUI window
        setTitle("Regular Vending Machine");
        setSize(600, 350);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        initComponents();
        pack();
        // Center the window on the screen
        setLocationRelativeTo(null);
    }

    /**
     * Initializes and sets up the components of the GUI, including the Test Features and Maintenance Features panels.
     * This method creates a main panel with a BorderLayout and adds a JTabbedPane to switch between the Test Features
     * and Maintenance Features menus. 
     */
    private void initComponents() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        setContentPane(mainPanel);

        // Create the Test Features and Maintenance panels
        JPanel testFeaturesPanel = createTestFeaturesPanel();
        JPanel maintenanceFeaturesPanel = createMaintenanceFeaturesPanel();

        // Create a tabbed pane to switch between Test Features and Maintenance menu
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Test Vending Features", testFeaturesPanel);
        tabbedPane.addTab("Maintenance Menu", maintenanceFeaturesPanel);

        mainPanel.add(tabbedPane, BorderLayout.CENTER);
    }

   /**
     * Creates and returns the panel for Test Features. The Test Features panel includes a text area to display output to the user
     * and a button for simulating the purchase of an item.
     *
     * @return The JPanel representing the Test Features panel.
     */
    private JPanel createTestFeaturesPanel() {
        JPanel testPanel = new JPanel(new BorderLayout());

        // A text area to display output to the user
        JTextArea outputTextArea = new JTextArea(10, 30);
        outputTextArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputTextArea);
        testPanel.add(scrollPane, BorderLayout.CENTER);

        // Button for simulating purchasing an item
        JButton purchaseButton = new JButton("Purchase Item");
        purchaseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                purchaseItem(outputTextArea);
            }
        });

        testPanel.add(purchaseButton, BorderLayout.SOUTH);

        return testPanel;
    }

    /**
     * Creates and returns the panel for Maintenance Features. The Maintenance Features panel includes a text area to display output to the user
     * and buttons for performing maintenance actions such as restocking items, displaying inventory, setting item prices, collecting payments,
     * making change, printing transaction history, and going back to the main menu.
     *
     * @return The JPanel representing the Maintenance Features panel.
    */
    private JPanel createMaintenanceFeaturesPanel() {
        // Create the main panel for Maintenance Features using a BorderLayout
        JPanel maintenancePanel = new JPanel(new BorderLayout());
        // Create a text area to display output to the user
        JTextArea outputTextArea = new JTextArea(10, 30);
        outputTextArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputTextArea);
        maintenancePanel.add(scrollPane, BorderLayout.CENTER);

        // Create buttons for various maintenance actions
        JButton restockButton = new JButton("Restock Items");
        restockButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String result = restockItems(outputTextArea);
                outputTextArea.append(result);
            }
        });

        JButton displayInventoryButton = new JButton("Display Inventory");
        displayInventoryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displayInventory(outputTextArea);
            }
        });

        JButton setPriceButton = new JButton("Set Item Price");
        setPriceButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setItemPrice(outputTextArea);
            }
        });

        JButton collectPaymentButton = new JButton("Collect Payment");
        collectPaymentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                collectPayment(outputTextArea);
            }
        });

        JButton makeChangeButton = new JButton("Make Change");
        makeChangeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                makeChange(outputTextArea);
            }
        });

        JButton printTransactionHistoryButton = new JButton("Print Transaction History");
        printTransactionHistoryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                printTransactionHistory(outputTextArea);
            }
        });


        JButton goBackButton = new JButton("Go Back to Main Menu");
        goBackButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Show a confirmation dialog before going back to the main menu
                int confirm = JOptionPane.showConfirmDialog(
                    RVMGUI.this,
                    "Are you sure you want to go back to the main menu?\nAny unsaved changes will be lost.",
                    "Confirm",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE
                );
        
                if (confirm == JOptionPane.YES_OPTION) {
                    // Switch back to the main tab of the main VendingMachineFactory 
                    mainFrame.switchToMainTab();
                    // Hides RVMGUI frame
                    setVisible(false);
                    // Makes main frame visible again
                    mainFrame.setVisible(true);
                }
            }
        });

        // Create button panel to hold maintenance action buttons
        JPanel buttonPanel = new JPanel(new GridLayout(3, 3));
        // Add buttons to panel
        buttonPanel.add(restockButton);
        buttonPanel.add(displayInventoryButton);
        buttonPanel.add(setPriceButton);
        buttonPanel.add(collectPaymentButton);
        buttonPanel.add(makeChangeButton);
        buttonPanel.add(printTransactionHistoryButton);
        buttonPanel.add(goBackButton);

        // Adds button panel to the bottom area
        maintenancePanel.add(buttonPanel, BorderLayout.SOUTH);

        return maintenancePanel;
    }

    /**
     * Restocks items in the vending machine based on user input. The method prompts the user to enter the quantity
     * to restock for each item, ensuring that the quantity entered is between 10 and 15 and does not exceed the
     * maximum capacity of 15. 
     *
     * @param outputTextArea The JTextArea where the restocking output and messages will be displayed.
     * @return A String containing the output messages of the restocking process.
     */
    private String restockItems(JTextArea outputTextArea) {
        // Initialize a StringBuilder to store the output messages of the restocking process
        StringBuilder restockOutput = new StringBuilder();
        // Create a flag to indicate if the input quantity is valid
        boolean isValid = false;

        // Append initial messages to the StringBuilder
        restockOutput.append("Restocking items:\n");
        restockOutput.append("Enter the quantity to restock for each item:\n");

         // Loop through each inventory item in the vending machine
        for (Inventory itemInventory : vendingMachine.getInventory()) {
            String itemName = itemInventory.getItem().getName();
            int currentQuantity = itemInventory.getQuantity();
            int maxCapacity = 15;
            int remainingCapacity = maxCapacity - currentQuantity;

            // Loop if user provides an invalid input
            while (!isValid) {
                String input = JOptionPane.showInputDialog(this, "Enter the quantity to restock for " + itemName +
                    " (Remaining capacity: " + remainingCapacity + "): ", "Restock Items", JOptionPane.PLAIN_MESSAGE);

                if (input == null) {
                    // User clicked the "Cancel" button for this item, skip to the next item
                    restockOutput.append("Restocking for " + itemName + " canceled.\n");
                    break;
                } 
                
                try {
                    int quantity = Integer.parseInt(input);
                    if (quantity < 10 || quantity > 15) {
                        JOptionPane.showMessageDialog(this, "Invalid input! Please enter a quantity between 10 and 15.", "Error", JOptionPane.ERROR_MESSAGE);
                    } else {
                        // Valid restocking quantity, add the items to the inventory and update output
                        int actualRestockQuantity = Math.min(quantity, remainingCapacity);
                        itemInventory.addItem(actualRestockQuantity);
                        restockOutput.append(actualRestockQuantity + " pieces of " + itemName + " restocked.\n");
                        isValid = true; // Exits the loop
                    }
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(this, "Invalid input! Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
        restockOutput.append("Items restocked successfully.\n\n");
        return restockOutput.toString();
    }

    /**
     * Sets the price of an item in the vending machine based on user input. The method prompts the user to enter the slot number
     * of the item whose price they want to set. Then, it prompts for the new price for that item. The input is validated to ensure
     * that the slot number is valid and that the new price is a valid positive number.
     *
     * @param outputTextArea The JTextArea where the output messages will be displayed.
     */
    private void setItemPrice(JTextArea outputTextArea) {
        // Flag to indicate if the input is valid
        boolean isValid = false;

        // Loops if user enters an invalid input
        while (!isValid) {
            String slotNumberInput = JOptionPane.showInputDialog(this, "Enter the slot number to set the price: ", "Slot Number of Item", JOptionPane.PLAIN_MESSAGE);
    
            if (slotNumberInput == null) {
                // User clicked the "Cancel" button
                outputTextArea.append("Setting of item price cancelled.\n\n");
                return; // Exit the method without making any changes
            }
    
            try {
                int slotNumber = Integer.parseInt(slotNumberInput);
                if (slotNumber >= 1 && slotNumber <= vendingMachine.getInventory().size()) {
                    // Valid slot number, get the selected item's inventory
                    int selectedIndex = slotNumber - 1;
                    Inventory selectedInventory = vendingMachine.getInventory().get(selectedIndex);
                    Item item = selectedInventory.getItem();
                    // Prompt the user to enter the new price for the selected item
                    String newPriceInput = JOptionPane.showInputDialog(this, "Enter the new price for " + item.getName() + ": ", "Set Item Price", JOptionPane.PLAIN_MESSAGE);
    
                    if (newPriceInput == null) {
                        // User clicked the "Cancel" button
                        outputTextArea.append("Setting of item price for " + item.getName() + " cancelled.\n\n");
                        return; // Exit the method without making any changes
                    }
    
                    try {
                        double newPrice = Double.parseDouble(newPriceInput);
                        item.setPrice(newPrice);
                        if (newPrice <= 0) {
                            // User clicked the "Cancel" button
                            outputTextArea.append("Setting of item price for " + item.getName() + " cancelled.\n\n");
                            return; // Exit the method without making any changes
                        }
                        // Valid price, update the item's price and output success message
                        outputTextArea.append("Price for " + item.getName() + " updated successfully.\n\n");
                        isValid = true; // Exits the loop
                    } catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(this, "Invalid input! Please enter a valid price.\n", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid Slot Number.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid input! Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
        
    /**
     * Calculates and displays the total amount of sales to be collected from the vending machine.
     * If there are no transactions and the total sales amount is zero, the method displays a message indicating no amount to collect.
     *
     * @param outputTextArea The JTextArea where the output message will be displayed.
     */
    private void collectPayment(JTextArea outputTextArea) {
        // Clear the outputTextArea before displaying the new output
        outputTextArea.setText("");
    
        // Get the total sales amount from the vending machine
        double totalSales = vendingMachine.getTotalSales();
    
        if (totalSales == 0) {
            outputTextArea.append("No amount to collect. There are no transactions.\n\n");
            return;
        }
        // Display total sales amount to be collected
        outputTextArea.append("Amount to Collect: Php " + totalSales + "\n");
    }
    
    /**
     * Handles the process of purchasing an item from the vending machine.
     * The method prompts the user to enter the amount they want to pay and the slot number of the item they wish to purchase.
     * The method displays the details of the selected item, the change (if any) to be given back, and updates the inventory and sales records.
     *
     * @param outputTextArea The JTextArea where the output messages will be displayed.
     */
    private void purchaseItem(JTextArea outputTextArea) {
        double amountPaid = 0; // Stores amount user is willing to pay
        int slotNumber = 0; // Stores the slot number of the item
        
        // Loops if user enters an invalid input
        while (true) {
            // Prompt the user to enter the amount they want to pay
            String amountPaidInput = JOptionPane.showInputDialog(this, "Enter the amount to pay: ", "Amount to Pay", JOptionPane.PLAIN_MESSAGE);
    
            if (amountPaidInput == null) {
                // User clicked the "Cancel" button
                outputTextArea.append("Purchase canceled.\n\n");
                return; // Exits the method without making any changes
            }
    
            try {
                amountPaid = Double.parseDouble(amountPaidInput);
                if (amountPaid <= 0) {
                    JOptionPane.showMessageDialog(this, "Invalid amount. Please enter a new amount to pay.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    break; // Exit the loop once a valid amount is entered
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid input! Please enter a valid number for the amount.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        
        // Display the available items for purchase
        outputTextArea.append("Available Items:\n");
        displayInventory(outputTextArea);
        
        // Loops if an invalid input entered
        while (true) {
            // Prompt the user to enter the slot number of the item they wish to purchase
            String slotNumberInput = JOptionPane.showInputDialog(this, "Enter the slot number to purchase the item: ", "Slot Number of Item", JOptionPane.PLAIN_MESSAGE);
    
            if (slotNumberInput == null) {
                // User clicked the "Cancel" button
                outputTextArea.append("Purchase canceled.\n\n");
                return; // Exits the method without making any changes
            }
    
            try {
                slotNumber = Integer.parseInt(slotNumberInput);
                if (slotNumber >= 1 && slotNumber <= vendingMachine.getInventory().size()) {
                    break; // Exit the loop once a valid slot number is entered
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid slot number.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid input! Please enter a valid number for the slot number.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        
         // Determine the item selected for purchase
        int selectedIndex = slotNumber - 1;
        Inventory selectedInventory = vendingMachine.getInventory().get(selectedIndex);
        Item item = selectedInventory.getItem();
        
        // Check if the selected item is available
        if (selectedInventory.getQuantity() > 0) {
            outputTextArea.append("Selected item: " + item.getName() + "\n");
            outputTextArea.append("Price: " + item.getPrice() + "\n");
            outputTextArea.append("Calories: " + item.getCalories() + "\n");
            
            // Check if the amount paid is sufficient for the purchase
            if (amountPaid >= item.getPrice()) {
                double change = amountPaid - item.getPrice();
                if (vendingMachine.hasSufficientChange(change)) {
                    selectedInventory.removeItem(1); // Reduce the quantity of the item by 1
                    vendingMachine.addToSales(item.getPrice()); // Add the item price to the total sales
                    vendingMachine.sales.add(item); // Add the purchased item to the sales list
                    outputTextArea.append("Item purchased successfully.\n");
                    outputTextArea.append("Change: " + change + "\n");
                    outputTextArea.append("Dispensing Item: " + item.getName() + "\n");   
                    // Update vending machine's cash balance and display the denominations of change
                    String changeOutput = vendingMachine.produceChange(change);
                    outputTextArea.append(changeOutput);
                } else {
                    outputTextArea.append("Insufficient change. Please try again later.\n\n");
                }
            } else {
                outputTextArea.append("Insufficient amount paid. Transaction canceled.\n\n");
            }
        } else {
            outputTextArea.append("Selected item is out of stock.\n\n");
        }
    }

    /**
     * Displays the current inventory of the vending machine in the output text area.
     * The method iterates through the items in the vending machine's inventory and formats the information
     * to display the slot number, item name, price, and quantity for each item.
     *
     * @param outputTextArea The JTextArea where the inventory information will be displayed.
     */
    private void displayInventory(JTextArea outputTextArea) {
        outputTextArea.append("Slot\tItem Name\tPrice\t\tQuantity\n");
        // Iterate through each item in the vending machine's inventory
        for (int i = 0; i < vendingMachine.getInventory().size(); i++) {
            Inventory itemInventory = vendingMachine.getInventory().get(i);
            Item item = itemInventory.getItem();
            String itemName = item.getName();
            double itemPrice = item.getPrice();
            int quantity = itemInventory.getQuantity();
            String slotLabel = "[" + (i + 1) + "]";
            String quantityLabel = (quantity > 0) ? String.valueOf(quantity) : "Out of stock";
            outputTextArea.append(String.format("%-8s%-16sPhp%8.2f    %s%n", slotLabel, itemName, itemPrice, quantityLabel));
        }
        outputTextArea.append("\n");
    }

    /**
     * Refills the change denominations in the vending machine with the quantities entered by the user.
     * The method iterates through the accepted cash denominations in the vending machine and prompts the user
     * to enter the quantity to refill for each denomination. The user's input is validated to ensure it is a positive
     * number, and the corresponding denomination's quantity is updated accordingly in the vending machine.
     *
     * @param outputTextArea The JTextArea where the refill status and messages will be displayed.
     */
    private void makeChange(JTextArea outputTextArea) {
        StringBuilder changeOutput = new StringBuilder();
        boolean isValid = false;
        
        changeOutput.append("Change refill:\n");
        
        // Iterate through each accepted cash denomination in the vending machine
        for (Map.Entry<Double, Denomination> entry : vendingMachine.getAcceptedCash().entrySet()) {
            // Loops if user's input is invalid
            while (!isValid) {
                 // Prompt the user to enter the quantity to refill for the current denomination
                String input = JOptionPane.showInputDialog(this, "Enter the quantity to refill for Php" + entry.getKey() + ": ", "Refill Money for Change", JOptionPane.PLAIN_MESSAGE);
        
                if (input == null) {
                    // User clicked the "Cancel" button, skip to the next amount
                    outputTextArea.append("Refill for Php" + entry.getKey() + " canceled.\n");
                    break;
                }
        
                try {
                    int quantity = Integer.parseInt(input);
                    if (quantity < 0) {
                        JOptionPane.showMessageDialog(this, "Invalid input! Please enter a positive quantity.", "Error", JOptionPane.ERROR_MESSAGE);
                    } else {
                        // Update the quantity of the current denomination in the vending machine
                        entry.getValue().setQuantity(entry.getValue().getQuantity() + quantity);
                        outputTextArea.append("Php " + entry.getKey() + " refilled successfully.\n");
                        isValid = true; // Move to the next denomination
                    }
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(this, "Invalid input! Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
            changeOutput.setLength(0); // Clear the StringBuilder for the next denomination
        }
    }

    /**
     * Prints the transaction history to the JTextArea.
     * The method retrieves the list of items sold from the vending machine's sales record.
     * It then constructs a summary of the transactions, including the name and price of each item sold,
     * and displays the summary in the given outputTextArea.
     *
     * @param outputTextArea The JTextArea where the transaction summary will be displayed.
    */
    private void printTransactionHistory(JTextArea outputTextArea) {
        StringBuilder transactionSummary = new StringBuilder("Transaction Summary:\n");

        for (Item item : vendingMachine.sales) {
            transactionSummary.append("Item: ").append(item.getName()).append(" - Price: ").append(item.getPrice()).append("\n");
        }

        outputTextArea.setText(transactionSummary.toString());
    }
}

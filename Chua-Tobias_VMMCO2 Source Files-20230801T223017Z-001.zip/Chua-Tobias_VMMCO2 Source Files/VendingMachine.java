import java.util.*;

/**
 * The abstract class representing a generic Vending Machine.
 * This class defines common functionalities and attributes for vending machines.
 * Specific types of vending machines can extend this class and implement their features.
 * 
 * @author Genelle Chua
 * @author Angela Tobias
 * @version 24.0
 */
abstract class VendingMachine {
    // Declare class attributes 
    protected Map<Double, Denomination> acceptedCash;
    protected List<Item> sales;
    protected double totalSales;

    /**
     * Constructor for the VendingMachine class.
     * Initializes the accepted cash, sales, and total sales attributes.
     *
     * @param acceptedCash The accepted cash denominations and their corresponding quantities.
     */
    public VendingMachine(Map<Double, Denomination> acceptedCash) {
        this.acceptedCash = acceptedCash;
        sales = new ArrayList<>();
        totalSales = 0.0;
    }

    /**
     * Abstract method for testing maintenance features of the vending machine.
     */    
    public abstract void testMaintenanceFeatures();

    /**
     * Abstract method for testing vending features of the vending machine.
     */
    public abstract void testVendingFeatures();

    /**
     * Allows testing maintenance features of the vending machine, including restocking of add-on items.
     * This method provides a way to test and manage inventory items in the vending machine,
     * specifically for a SpecialVendingMachine that supports add-on items.
     * 
     * @param scanner The Scanner object to get user input.
     * @param vendingMachine The VendingMachine object being tested.
     */
    protected void testMaintenanceFeatures(Scanner scanner, VendingMachine vendingMachine) {
        System.out.println("\nMaintenance Testing Mode");
        
        // Check if the vending machine is of type SpecialVendingMachine
        if (vendingMachine instanceof SpecialVendingMachine) {
            System.out.println("Current Add-On Item Quantities:");
            SpecialVendingMachine specialMachine = (SpecialVendingMachine) vendingMachine;
    
            // Define the restockItems map to store the quantities for each add-on item
            Map<String, Integer> restockItems = new HashMap<>();
            // Loop through each inventory item in the SpecialVendingMachine
            for (Inventory inventoryItem : specialMachine.getInventory()) {
                System.out.print("Enter the quantity to restock for " + inventoryItem.getItem().getName() + ": ");
                int quantity = scanner.nextInt();
                scanner.nextLine(); // Consume the newline character
                restockItems.put(inventoryItem.getItem().getName(), quantity);
            }
        }
    
        System.out.println("\nMaintenance Testing Complete.");
    }

    /**
     * Allows the vending machine to accept payment from the user for a given required amount.
     *
     * @param scanner The Scanner object to get user input for the payment amount.
     * @param requiredAmount The amount that needs to be paid by the user.
     * @return The change amount (if any) after the payment is successful, or 0.0 if the payment is insufficient or canceled.
     */
    protected double acceptPayment(Scanner scanner, double requiredAmount) {
        System.out.print("Enter the amount to pay (or 0 to cancel): ");
        double amountPaid = scanner.nextDouble();
        scanner.nextLine(); // Consume the newline character

        if (amountPaid < requiredAmount) {
            System.out.println("Insufficient payment. Please pay the correct amount.");
            return 0.0;
        } else {
            double change = amountPaid - requiredAmount;
            System.out.println("Payment successful. Change: " + change);
            return change;
        }
    }

    /**
     * Adds the price of an item to the total sales of the vending machine.
     *
     * @param itemPrice The price of the item to be added to the total sales.
     */
    protected void addToSales(double itemPrice) {
        totalSales += itemPrice;
    }
    
    /**
     * Dispenses change to the user by printing the denominations and quantities of each denomination.
     * It also updates the quantity of each denomination in the acceptedCash map after dispensing the change.
     *
     * @param changeToDispense A Map representing the denominations and quantities of change to be dispensed.
     */
    protected void dispenseChange(Map<Double, Integer> changeToDispense) {
        System.out.println("Dispensing change with the following denominations...");
        for (Map.Entry<Double, Integer> entry : changeToDispense.entrySet()) {
            double denomination = entry.getKey();
            int numNotes = entry.getValue();
            System.out.println(numNotes + " x Php " + denomination);
            acceptedCash.get(denomination).decrementQuantity(numNotes);
        }
    }

    /**
     * Collects payments made during item purchases.
     */
    protected abstract void collectPayment();

    /**
     * Prints a summary of the transactions made in the vending machine.
     * It displays the name and price of each item sold and the total sales amount.
     */
    public void printTransactionSummary() {
        System.out.println("Transaction Summary:");
        for (Item item : sales) {
            System.out.println("Item: " + item.getName() + " - Price: " + item.getPrice());
        }
        System.out.println("Total Sales: " + totalSales);
    }

    /**
     * Displays the accepted denominations and their quantities in the vending machine.
     * This method prints a list of accepted denominations along with the quantity of each denomination
     * that the vending machine currently holds in its cash inventory.
     */
    protected void displayAcceptedCash() {
        System.out.println("Accepted Denominations:");
        for (Map.Entry<Double, Denomination> entry : acceptedCash.entrySet()) {
            double denomination = entry.getKey();
            Denomination denominationObj = entry.getValue();
            int quantity = denominationObj.getQuantity();
            System.out.println("Php " + denomination + ": " + quantity);
        }
    }

    /**
     * Checks if the vending machine has sufficient change to give back to the customer for the specified amount.
     * This method determines whether the vending machine has enough change, in the form of accepted denominations,
     * to provide to the customer for the given amount.
     *
     * @param amount The amount for which change is to be provided.
     * @return {@code true} if the vending machine has sufficient change, {@code false} otherwise.
     */
    public boolean hasSufficientChange(double amount) {
        List<Double> availableDenominations = new ArrayList<>(acceptedCash.keySet());
        Collections.sort(availableDenominations, Collections.reverseOrder());
    
        double remainingAmount = amount;
        for (double denomination : availableDenominations) {
            int numNotes = (int) (remainingAmount / denomination);
            if (numNotes > 0) {
                Denomination denominationObj = acceptedCash.get(denomination);
                if (denominationObj.getQuantity() >= numNotes) {
                    remainingAmount -= (denomination * numNotes);
                } else {
                    // returns false, if there are not enough notes for this denomination
                    return false;
                }
            }
        }
    
        // If the remaining amount is zero, allows forming the change using available denominations
        return remainingAmount == 0.0;
    }

    /**
     * Adds the specified denomination to the vending machine's cash inventory.
     * This method is used to replenish the vending machine's cash inventory with the provided denomination.
     *
     * @param changeDenomination The denomination to be added to the cash inventory.
     */
    public void addChange(Denomination changeDenomination){
        double denominationValue = changeDenomination.getValue();
        if (acceptedCash.containsKey(denominationValue)) {
            Denomination existingDenomination = acceptedCash.get(denominationValue);
            int currentQuantity = existingDenomination.getQuantity();
            int additionalQuantity = changeDenomination.getQuantity();
            existingDenomination.setQuantity(currentQuantity + additionalQuantity);
        } else {
            acceptedCash.put(denominationValue, changeDenomination);
        }
    }
}
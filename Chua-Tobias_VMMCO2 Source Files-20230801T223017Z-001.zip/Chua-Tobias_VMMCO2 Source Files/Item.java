/**
 * The Item class represents an item that can be sold in the vending machine.
 * Each item has a name, price, and calorie information.
 * 
 * @author Genelle Chua
 * @author Angela Tobias
 * @version 24.0
 */
class Item {
    // Declare class attributes 
    private String name;
    private double price;
    private int calories;

    /**
     * Constructs an Item object with the given name, price, and calorie information.
     *
     * @param name     The name of the item.
     * @param price    The price of the item.
     * @param calories The calorie information of the item.
     */
    public Item(String name, double price, int calories) {
        this.name = name;
        this.price = price;
        this.calories = calories;
    }

    /**
     * Returns the name of the item.
     *
     * @return The name of the item.
     */
    public String getName() {
        return name;
    }

    /**
     * Returns the price of the item.
     *
     * @return The price of the item.
     */
    public double getPrice() {
        return price;
    }

    /**
     * Sets the price of the item.
     *
     * @param price The new price of the item.
     */
    public void setPrice(double price) {
        this.price = price;
    }

    /**
     * Returns the calorie information of the item.
     *
     * @return The calorie information of the item.
     */
    public int getCalories() {
        return calories;
    }

    /**
     * Sets the calorie information of the item.
     *
     * @param calories The new calorie information of the item.
     */
    public void setCalories(int calories) {
        this.calories = calories;
    }
}

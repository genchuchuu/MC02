import java.util.*;

/**
 * A class representing a Regular Vending Machine, which is a type of VendingMachine.
 * This class extends the VendingMachine class and implements specific methods and features for a regular vending machine.
 * 
 * @author Genelle Chua
 * @author Angela Tobias
 * @version 24.0
 */
class RegularVendingMachine extends VendingMachine {
    // Declare class attributes 
    protected List<Inventory> in; // List to store the inventory of items in the vending machine

    /**
     * Constructor to create a RegularVendingMachine object with the given inventory and accepted cash denominations.
     *
     * @param inventory     The list of Inventory objects representing the initial inventory of the vending machine.
     * @param acceptedCash  The map of accepted cash denominations and their corresponding Denomination objects.
     */
    public RegularVendingMachine(List<Inventory> inventory, Map<Double, Denomination> acceptedCash) {
        super( acceptedCash);
        this.in = new ArrayList<>(inventory);
    }

    /**
     * Method to test maintenance features of the vending machine.
     * It displays a maintenance menu with options such as restocking items, setting item prices, collecting payment,
     * adding money for change, printing transaction summaries, and returning to the test a vending machine menu.
     */
    @Override
    public void testMaintenanceFeatures() {
        // Create a Scanner object to read user input from the console
        Scanner scanner = new Scanner(System.in);

        // Loops if user provides an invalid input
        while (true) {
            System.out.println("\nMaintenance Menu:");
            System.out.println("[1] Restock Items");
            System.out.println("[2] Set Item Price");
            System.out.println("[3] Collect Payment");
            System.out.println("[4] Add Money For Change");
            System.out.println("[5] Print Transaction Summary");
            System.out.println("[6] Return to Test a Vending Machine Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    restockItems(scanner);
                    break;
                case 2:
                    setItemPrice(scanner);
                    break;
                case 3:
                    collectPayment();
                    break;
                case 4:
                    makeChange(scanner);
                    break;
                case 5:
                    printTransactionSummary();
                    break;
                case 6:
                    return; // Return to the test a vending machine menu
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    /**
     * Method to test vending features of the vending machine.
     * It displays a vending machine test menu with options such as purchasing items and returning to the main menu.
     * The method takes input from the user to perform the chosen vending operation.
     * It uses a Scanner object to read user input from the console.
     */
    @Override
    public void testVendingFeatures() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nVending Machine Test Menu:");
            System.out.println("[1] Purchase Item");
            System.out.println("[2] Return to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    purchaseItem(scanner);
                    break;
                case 2:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    /**
     * Returns the map of accepted cash denominations along with their corresponding quantities.
     * 
     * @return The map of accepted cash denominations and their quantities.
     */
    public Map<Double, Denomination> getAcceptedCash() {
        return acceptedCash;
    }
    
    /**
     * Produces the change in the form of denominations for the specified change amount.
     * It deducts the dispensed denominations from the acceptedCash map.
     * 
     * @param change The amount of change to be produced.
     * @return A formatted string containing the denominations and quantities of change dispensed.
     */
    protected String produceChange(double change) {
        StringBuilder changeOutput = new StringBuilder();

        changeOutput.append("Dispensing change with the following denominations...\n");
        
        // Sort the denominations in descending order
        List<Double> denominations = new ArrayList<>(acceptedCash.keySet());
        Collections.sort(denominations, Collections.reverseOrder());

        for (double denomination : denominations) {
            int quantityAvailable = acceptedCash.get(denomination).getQuantity();

            if (change >= denomination && quantityAvailable > 0) {
                int numOfBills = (int) (change / denomination);
                int numOfBillsToDispense = Math.min(numOfBills, quantityAvailable);
                change -= numOfBillsToDispense * denomination;

                // Adjust the cash balance by reducing the quantity of the denomination used
                acceptedCash.get(denomination).setQuantity(quantityAvailable - numOfBillsToDispense);

                changeOutput.append("Php ").append(denomination).append(" x ").append(numOfBillsToDispense).append("\n");
            }
        }
        return changeOutput.toString();
    }

    /**
     * Get the total sales amount of the vending machine.
     *
     * @return The total sales amount.
     */
    public double getTotalSales() {
        return totalSales;
    }

    /**
     * Add the given amount to the sales of the vending machine.
     *
     * @param amount The amount to add to the sales.
     */
    protected void addToSales(double amount) {
        super.addToSales(amount);
        totalSales += amount;
    }

    /**
     * Restock items in the vending machine inventory.
     *
     * @param scanner The Scanner object to read user input.
     */
    protected void restockItems(Scanner scanner) {
        System.out.println("\nCurrent Inventory:");
        displayInventory();

        for (Inventory itemInventory : in) {
            System.out.print("Enter the quantity to restock for 10 up to 15 pieces only " + itemInventory.getItem().getName() + ": ");
            int quantity = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character
            
            // If the current quantity is already 11, inform the user and ask for confirmation to proceed
            if (itemInventory.getQuantity() == 11) {
                System.out.println("Maximum inventory of " + 11 + " reached for " + itemInventory.getItem().getName() + ". Restocking not allowed.");
                System.out.print("Do you want to cancel restocking? (Y/N): ");
                String input = scanner.nextLine().trim().toLowerCase();

                if (input.equals("y")) {
                    System.out.println("Restocking canceled.");
                    return;
                }
            }

            // Ask the user to enter a valid quantity between 10 and 15.
            while (quantity < 10 || quantity > 15) {
                System.out.println("Invalid input! Please try again");
                System.out.print("Enter the quantity to restock for " + itemInventory.getItem().getName() + ": ");
                quantity = scanner.nextInt();
                scanner.nextLine(); // Consume the newline character
            }

            itemInventory.addItem(quantity);
        }

        System.out.println("Items restocked successfully.");
    }

    /**
     * Display the current inventory of the vending machine.
     */
    protected void displayInventory() {
        System.out.println("Slot\tItem Name\tPrice\t\tQuantity");
        for (int i = 0; i < in.size(); i++) {
            Inventory itemInventory = in.get(i);
            Item item = itemInventory.getItem();
            String itemName = item.getName();
            double itemPrice = item.getPrice();
            int quantity = itemInventory.getQuantity();
            String slotLabel = "[" + (i + 1) + "]";
            String quantityLabel = (quantity > 0) ? String.valueOf(quantity) : "Out of stock";
            System.out.printf("%-8s%-16sPhp%8.2f    %s%n", slotLabel, itemName, itemPrice, quantityLabel);
        }
    }

    /**
     * Displays message saying that payments have been collected.
     */
    @Override
    protected void collectPayment() {
        System.out.println("Collecting payment...");
        System.out.println("Payment collected successfully.");
    }

    /**
     * Refills the change in the vending machine with the specified quantity of each denomination.
     *
     * @param scanner The Scanner object to get user input.
     */
    public void makeChange(Scanner scanner) {
        for (Map.Entry<Double, Denomination> entry : acceptedCash.entrySet()) {
            System.out.print("Enter the quantity to refill for Php" + entry.getKey() + ": ");
            int quantity = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character
            entry.getValue().setQuantity(entry.getValue().getQuantity() + quantity);
        }
    
        System.out.println("Change refill successful.");
    }
    
    /**
     * Dispenses the item from the specified slot number.
     *
     * @param slotNumber The slot number from which to dispense the item.
     */
    protected void dispenseItem(int slotNumber) {
        Inventory item = in.get(slotNumber - 1);
        System.out.println("Dispensed item: " + item.getItem().getName());
    }
    
    /**
     * Calculates and prints the total number of items in the inventory.
     */
    protected void calculateTotalInventory() {
        int totalItems = 0;
        for (Inventory item : in) {
            totalItems += item.getQuantity();
        }
        System.out.println("Total inventory: " + totalItems);
    }

    /**
     * Get the list of Inventory objects representing the current inventory of the vending machine.
     *
     * @return The List of Inventory objects representing the current inventory.
     */
    public List<Inventory> getInventory() {
        return in;
    }

    /**
     * Set the price of an item in the vending machine.
     *
     * @param scanner The Scanner object used for user input.
     */
    protected void setItemPrice(Scanner scanner) {
        System.out.println("\nCurrent Inventory:");
        displayInventory();

        System.out.print("Enter the slot number to set the price: ");
        int slotNumber = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        if (slotNumber >= 1 && slotNumber <= in.size()) {
            int selectedIndex = slotNumber - 1;
            Inventory selectedInventory = in.get(selectedIndex);
            Item item = selectedInventory.getItem();

            System.out.print("Enter the new price for " + item.getName() + ": ");
            double newPrice = scanner.nextDouble();
            scanner.nextLine(); // Consume the newline character

            item.setPrice(newPrice);
            System.out.println("Price for " + item.getName() + " updated successfully.");
        } else {
            System.out.println("Invalid slot number.");
        }
    }

    /**
     * Allows a user to purchase an item from the vending machine.
     *
     * @param scanner The Scanner object used for user input.
     */
    public void purchaseItem(Scanner scanner) {
        System.out.print("Enter the amount to pay (or 0 to cancel): ");
        double amountPaid = scanner.nextDouble();
        scanner.nextLine(); // Consume the newline character
    
        if (amountPaid == 0) {
            System.out.println("Purchase canceled.");
            return;
        }
    
        System.out.println("\nAvailable Items:");
        displayInventory();
    
        System.out.print("Enter the slot number to purchase the item: ");
        int slotNumber = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character
    
        if (slotNumber >= 1 && slotNumber <= in.size()) {
            Inventory selectedInventory = in.get(slotNumber - 1);
            Item item = selectedInventory.getItem();
    
            if (selectedInventory.getQuantity() > 0) {
                System.out.println("Selected item: " + item.getName());
                System.out.println("Price: " + item.getPrice());
                System.out.println("Calories: " + item.getCalories());
    
                if (amountPaid >= item.getPrice()) {
                    double change = amountPaid - item.getPrice();
                    if (hasSufficientChange(change)) {
                        selectedInventory.removeItem(1);
                        addToSales(item.getPrice()); 
                        totalSales += item.getPrice();
                        System.out.println("Item purchased successfully.");
                        System.out.println("Change: " + change);
                        System.out.println("Dispensing Item: " + item.getName());
                        System.out.println("Dispensing change with the following denominations...");
                        produceChange(change); 
                    } else {
                        System.out.println("Insufficient change. Please try again later.");
                    }
                } else {
                    System.out.println("Insufficient amount paid. Transaction canceled.");
                }
            } else {
                System.out.println("Selected item is out of stock.");
            }
        } else {
            System.out.println("Invalid slot number.");
        }
    }
    
}
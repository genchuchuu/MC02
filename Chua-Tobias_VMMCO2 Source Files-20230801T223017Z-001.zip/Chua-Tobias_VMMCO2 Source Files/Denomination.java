/**
 * The Denomination class represents a specific denomination of currency accepted by the vending machine.
 * It holds information about the value and the quantity of this denomination in the vending machine's cash balance.
 * 
 * @author Genelle Chua
 * @author Angela Tobias
 * @version 24.0
 */
class Denomination {
    // Declare class attributes 
    private double value;
    private int quantity;

    /**
     * Constructs a Denomination object with the given value.
     * The initial quantity is set to 0 by default.
     *
     * @param value The value of this denomination.
     */
    public Denomination(double value) {
        this.value = value;
        this.quantity = 0; // Initialize the quantity to 0 by default
    }

    /**
     * Returns the value of this denomination.
     *
     * @return The value of this denomination.
     */
    public double getValue() {
        return value;
    }

    /**
     * Returns the current quantity of this denomination in the cash balance.
     *
     * @return The current quantity of this denomination in the cash balance.
     */
    public int getQuantity() {
        return quantity;
    }

    /**
     * Sets the quantity of this denomination in the cash balance.
     *
     * @param quantity The new quantity of this denomination in the cash balance.
     */
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    /**
     * Increments the quantity of this denomination by the specified quantityToAdd.
     * If the given quantityToAdd is negative, the method throws an IllegalArgumentException.
     *
     * @param quantityToAdd The quantity to add to the current quantity of this denomination.
     * @throws IllegalArgumentException If the quantityToAdd is negative.
     */
    public void incrementQuantity(int quantityToAdd) {
        if (quantityToAdd < 0) {
            throw new IllegalArgumentException("Quantity to add must be non-negative.");
        }
        this.quantity += quantityToAdd;
    }

    /**
     * Decrements the quantity of this denomination by the specified quantityToSubtract.
     * If the given quantityToSubtract is negative or greater than the current quantity,
     * the method throws an IllegalArgumentException.
     *
     * @param quantityToSubtract The quantity to subtract from the current quantity of this denomination.
     * @throws IllegalArgumentException If the quantityToSubtract is negative or greater than the current quantity.
     */
    public void decrementQuantity(int quantityToSubtract) {
        if (quantityToSubtract < 0) {
            throw new IllegalArgumentException("Quantity to subtract must be non-negative.");
        }
        if (quantityToSubtract > this.quantity) {
            throw new IllegalArgumentException("Insufficient quantity to subtract.");
        }
        this.quantity -= quantityToSubtract;
    }
}

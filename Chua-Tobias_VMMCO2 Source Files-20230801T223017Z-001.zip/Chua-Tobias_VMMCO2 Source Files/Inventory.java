/**
 * The Inventory class represents the inventory of a specific item in the vending machine.
 * It holds information about the item and its current quantity in stock.
 * 
 * @author Genelle Chua
 * @author Angela Tobias
 * @version 24.0
 */
public class Inventory {
    // Declare class attributes
    private Item item;
    private int quantity;

    /**
     * Constructs an Inventory object with the given item and quantity.
     *
     * @param item     The item to be stored in this inventory.
     * @param quantity The initial quantity of the item in stock.
     */
    public Inventory(Item item, int quantity) {
        this.item = item;
        this.quantity = quantity;
    }

    /**
     * Returns the item stored in this inventory.
     *
     * @return The item stored in this inventory.
     */
    public Item getItem() {
        return item;
    }

    /**
     * Sets the item stored in this inventory.
     *
     * @param item The new item to be stored in this inventory.
     */
    public void setItem(Item item) {
        this.item = item;
    }

    /**
     * Returns the current quantity of the item in stock.
     *
     * @return The current quantity of the item in stock.
     */
    public int getQuantity() {
        return quantity;
    }

    /**
     * Sets the quantity of the item in stock.
     *
     * @param quantity The new quantity of the item in stock.
     */
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    /**
     * Decrements the quantity of the item in stock by 1.
     * If the quantity becomes negative, it is not changed and remains 0.
     */
    public void decrementQuantity() {
        if (quantity > 0) {
            quantity--;
        }
    }

    /**
     * Adds the specified quantity to the current quantity in stock.
     * If the given quantityToAdd is negative, the method throws an IllegalArgumentException.
     *
     * @param quantityToAdd The quantity to add to the current quantity in stock.
     * @throws IllegalArgumentException If the quantityToAdd is negative.
     */
    public void addQuantity(int quantityToAdd) {
        this.quantity += quantityToAdd;
        if (this.quantity < 0) {
            this.quantity = 0; // Prevent negative quantity
        }
    }

    /**
     * Adds the specified quantity to the current quantity in stock.
     * If the given quantity is negative, the method throws an IllegalArgumentException.
     *
     * @param quantity The quantity to add to the current quantity in stock.
     * @throws IllegalArgumentException If the quantity is negative.
     */
    public void addItem(int quantity) {
        if (quantity < 0) {
            throw new IllegalArgumentException("Quantity must be non-negative.");
        }
        this.quantity += quantity;
    }

    /**
     * Removes the specified quantity from the current quantity in stock.
     * If the given quantity is negative, the method throws an IllegalArgumentException.
     *
     * @param quantity The quantity to remove from the current quantity in stock.
     * @throws IllegalArgumentException If the quantity is negative.
     */
    public void removeItem(int quantity) {
        if (quantity < 0) {
            throw new IllegalArgumentException("Quantity must be non-negative.");
        }
        this.quantity -= quantity;
    }
}

/**
 * The CustomDrink class represents a customizable drink item in the vending machine.
 * It extends the Item class and adds properties for customizations such as cup size,
 * temperature, sugar level, milk choice, and the number of espresso shots.
 * 
 * @author Genelle Chua
 * @author Angela Tobias
 * @version 24.0
 */
public class CustomDrink extends Item {
    // Declare class attributes
    private String drinkName;
    private String cupSize;
    private String temperature;
    private String sugarLevel;
    private String milkChoice;
    private int numEspressoShots; 

    /**
     * Constructs a CustomDrink object with the given drink name.
     * The initial price and calories are set to 0, as they will be calculated based on customizations.
     *
     * @param drinkName The name of the custom drink.
     */
    public CustomDrink(String drinkName) {
        super(drinkName, 0, 0); // Setting the initial price and calories to 0, as they will be calculated based on customizations
        this.drinkName = drinkName;
    }

    // Getters and setters for the customization options

    /**
     * Returns the name of the custom drink.
     *
     * @return The name of the custom drink.
     */
    public String getDrinkName() {
        return drinkName;
    }

    /**
     * Returns the selected cup size for the custom drink.
     *
     * @return The selected cup size for the custom drink.
     */
    public String getCupSize() {
        return cupSize;
    }

    /**
     * Sets the selected cup size for the custom drink.
     *
     * @param cupSize The selected cup size for the custom drink.
     */
    public void setCupSize(String cupSize) {
        this.cupSize = cupSize;
    }

    /**
     * Returns the selected temperature for the custom drink.
     *
     * @return The selected temperature for the custom drink.
     */
    public String getTemperature() {
        return temperature;
    }

    /**
     * Sets the selected temperature for the custom drink.
     *
     * @param temperature The selected temperature for the custom drink.
     */
    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }

    /**
     * Returns the selected sugar level for the custom drink.
     *
     * @return The selected sugar level for the custom drink.
     */
    public String getSugarLevel() {
        return sugarLevel;
    }

    /**
     * Sets the selected sugar level for the custom drink.
     *
     * @param sugarLevel The selected sugar level for the custom drink.
     */
    public void setSugarLevel(String sugarLevel) {
        this.sugarLevel = sugarLevel;
    }

    /**
     * Returns the selected milk choice for the custom drink.
     *
     * @return The selected milk choice for the custom drink.
     */
    public String getMilkChoice() {
        return milkChoice;
    }

    /**
     * Sets the selected milk choice for the custom drink.
     *
     * @param milkChoice The selected milk choice for the custom drink.
     */
    public void setMilkChoice(String milkChoice) {
        this.milkChoice = milkChoice;
    }

    /**
     * Returns the number of espresso shots for the custom drink.
     *
     * @return The number of espresso shots for the custom drink.
     */
    public int getNumEspressoShots() {
        return numEspressoShots;
    }

    /**
     * Sets the number of espresso shots for the custom drink.
     *
     * @param numEspressoShots The number of espresso shots for the custom drink.
     */
    public void setNumEspressoShots(int numEspressoShots) {
        this.numEspressoShots = numEspressoShots;
    }
}

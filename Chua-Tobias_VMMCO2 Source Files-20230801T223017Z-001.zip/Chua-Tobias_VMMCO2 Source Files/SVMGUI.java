import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Map;

/**
 * The SVMGUI class represents the graphical user interface for the Special Vending Machine (SVM).
 * It allows users to interact with the SVM by providing various features for testing and maintenance.
 * 
 * @author Genelle Chua
 * @author Angela Tobias
 * @version 24.0
 */
public class SVMGUI extends JFrame {
    // Declare class attributes 
    private SpecialVendingMachine vendingMachine;
    private VendingMachineFactory mainFrame;
    private JTextArea outputTextArea;
    private JButton purchaseButton;

    /**
     * Constructs a new SVMGUI object with the provided SpecialVendingMachine and VendingMachineFactory objects.
     *
     * @param vendingMachine The SpecialVendingMachine associated with this GUI.
     * @param mainFrame      The main VendingMachineFactory frame.
     */
    public SVMGUI(SpecialVendingMachine vendingMachine, VendingMachineFactory mainFrame) {
        this.vendingMachine = vendingMachine;
        this.mainFrame = mainFrame;
        setTitle("Special Vending Machine");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        initComponents();
        pack();
        setLocationRelativeTo(null);
    }

    /**
     * Initializes the components of the SVMGUI, setting up the main panel and creating the Test Features and Maintenance panels.
     */
    private void initComponents() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        setContentPane(mainPanel);

        // Create the Test Features and Maintenance panels
        JPanel testFeaturesPanel = createTestFeaturesPanel();
        JPanel maintenanceFeaturesPanel = createMaintenanceFeaturesPanel();

        // Create a tabbed pane to switch between Test Features and Maintenance menu
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Test Vending Features", testFeaturesPanel);
        tabbedPane.addTab("Maintenance Menu", maintenanceFeaturesPanel);

        mainPanel.add(tabbedPane, BorderLayout.CENTER);
    }

    /**
     * Creates the Test Features panel for the SVMGUI, containing a text area to display output and a button to simulate purchasing an item.
     *
     * @return The JPanel representing the Test Features panel.
     */
    private JPanel createTestFeaturesPanel() {
        JPanel testPanel = new JPanel(new BorderLayout());
    
        // A text area to display output to the user
        outputTextArea = new JTextArea(10, 30);
        outputTextArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputTextArea);
        testPanel.add(scrollPane, BorderLayout.CENTER);
    
        // Button for simulating purchasing an item
        purchaseButton = new JButton("Purchase Item");
        purchaseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                purchaseItem(outputTextArea);
            }
        });
        testPanel.add(purchaseButton, BorderLayout.SOUTH);
    
        return testPanel;
    }
    
    /**
     * Creates the Maintenance Features panel for the SVMGUI, containing buttons for various maintenance actions and a text area to display output.
     *
     * @return The JPanel representing the Maintenance Features panel.
     */
    private JPanel createMaintenanceFeaturesPanel() {
        // Create panel and text area for output
        JPanel maintenancePanel = new JPanel(new BorderLayout());
        JTextArea outputTextArea = new JTextArea(10, 30);
        outputTextArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputTextArea);
        maintenancePanel.add(scrollPane, BorderLayout.CENTER);

        // Initialize buttons
        JButton restockButton = new JButton("Restock Items");
        restockButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                restockItems(outputTextArea);
            }
        });

        JButton displayInventoryButton = new JButton("Display Inventory");
        displayInventoryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displayInventory(outputTextArea);
            }
        });

        JButton setPriceButton = new JButton("Set Item Price");
        setPriceButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setItemPrice(outputTextArea);
            }
        });

        JButton collectPaymentButton = new JButton("Collect Payment");
        collectPaymentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                collectPayment(outputTextArea);
            }
        });

        JButton makeChangeButton = new JButton("Make Change");
        makeChangeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                makeChange(outputTextArea);
            }
        });

        JButton printTransactionHistoryButton = new JButton("Print Transaction History");
        printTransactionHistoryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                printTransactionSummary(outputTextArea);
            }
        });

        JButton goBackButton = new JButton("Go Back to Main Menu");
        goBackButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Show a confirmation dialog before going back to the main menu
                int confirm = JOptionPane.showConfirmDialog(
                    SVMGUI.this,
                    "Are you sure you want to go back to the main menu?\nAny unsaved changes will be lost.",
                    "Confirm",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE
                );
        
                if (confirm == JOptionPane.YES_OPTION) {
                    // Switch back to the main tab of the main VendingMachineFactory 
                    mainFrame.switchToMainTab();
                    // Hides SVMGUI frame
                    setVisible(false);
                    // Makes main frame visible again
                    mainFrame.setVisible(true);
                }
            }
        });

        // Panel to hold the buttons in a grid layout
        JPanel buttonPanel = new JPanel(new GridLayout(3, 3));
        buttonPanel.add(restockButton);
        buttonPanel.add(displayInventoryButton);
        buttonPanel.add(setPriceButton);
        buttonPanel.add(collectPaymentButton);
        buttonPanel.add(makeChangeButton);
        buttonPanel.add(printTransactionHistoryButton);
        buttonPanel.add(goBackButton);

        maintenancePanel.add(buttonPanel, BorderLayout.SOUTH);

        return maintenancePanel;
    }

    /**
     * Displays a message in the output text area to indicate the preparation process of a custom drink.
     *
     * @param customDrink The CustomDrink object representing the customized drink to be prepared.
     */
    private void displayPrepareDrinkMessage(CustomDrink customDrink) {
        outputTextArea.append("\nPreparing the drink: " + customDrink.getDrinkName() + "\n");
        outputTextArea.append("Customizations:\n");
        outputTextArea.append("Cup Size: " + customDrink.getCupSize() + "\n");
        outputTextArea.append("Temperature: " + customDrink.getTemperature() + "\n");
        outputTextArea.append("Sugar Level: " + customDrink.getSugarLevel() + "\n");
        outputTextArea.append("Milk Choice: " + customDrink.getMilkChoice() + "\n");
        outputTextArea.append("Espresso Shots: " + customDrink.getNumEspressoShots() + "\n");
        outputTextArea.append("\nMixing the drink...\n");
        outputTextArea.append("\nPouring the drink to cup " + customDrink.getCupSize() + "\n");
    }

    /**
     * Retrieves the name of the drink based on the user's choice.
     *
     * @param choice An integer representing the user's choice for the drink (0 for White Chocolate Coffee, 1 for Caramel Macchiato).
     * @return The name of the selected drink or null if the choice is invalid.
     */
    private String getDrinkNameByChoice(int choice) {
        switch (choice) {
            case 0:
                return "White Chocolate Coffee";
            case 1:
                return "Caramel Macchiato";
            default:
                return null;
        }
    }

    /**
     * Generates an order summary for a custom drink with its customizations, total calories, and total price.
     *
     * @param customDrink The CustomDrink object representing the customized drink.
     * @param totalCalories The total calories of the custom drink.
     * @param totalPrice The total price of the custom drink.
     * @return The order summary as a formatted string.
     */
    private String getOrderSummary(CustomDrink customDrink, int totalCalories, double totalPrice) {
        String orderSummary = "Order Summary:\n";
        orderSummary += "Customizations:\n";
        orderSummary += "Cup Size: " + customDrink.getCupSize() + "\n";
        orderSummary += "Temperature: " + customDrink.getTemperature() + "\n";
        orderSummary += "Sugar Level: " + customDrink.getSugarLevel() + "\n";
        orderSummary += "Milk Choice: " + customDrink.getMilkChoice() + "\n";
        orderSummary += "Espresso Shots: " + customDrink.getNumEspressoShots() + "\n";
        orderSummary += "Total Calories: " + totalCalories + "\n";
        orderSummary += "Total Price: Php " + totalPrice + "\n";
        return orderSummary;
    }

    /**
     * Restocks items in the vending machine inventory.
     * The method prompts the user to input the quantity to restock for each item.
     * The restocking quantity must be between 10 and 15, and it cannot exceed the remaining capacity (up to a maximum of 15) for each item.
     * If the user cancels the restocking for a specific item, the method skips to the next item.
     *
     * @param outputTextArea The JTextArea used to display the output and messages to the user.
     */
    private void restockItems(JTextArea outputTextArea) {
        // Restock Items
        for (Inventory itemInventory : vendingMachine.getInventory()) {
            String itemName = itemInventory.getItem().getName();
            int currentQuantity = itemInventory.getQuantity();
            int maxCapacity = 15;
            int remainingCapacity = maxCapacity - currentQuantity;

            boolean isValid = false;

            while (!isValid) {
                String input = JOptionPane.showInputDialog(this, "Enter the quantity to restock for " + itemName +
                        " (Remaining capacity: " + remainingCapacity + "): ", "Restock Items", JOptionPane.PLAIN_MESSAGE);

                if (input == null) {
                    // User clicked the "Cancel" button for this item, skip to the next item
                    outputTextArea.append("Restocking for " + itemName + " canceled.\n");
                    break;
                }

                try {
                    int quantity = Integer.parseInt(input);
                    if (quantity < 10 || quantity > 15) {
                        JOptionPane.showMessageDialog(this, "Invalid input! Please enter a quantity between 10 and 15.", "Error", JOptionPane.ERROR_MESSAGE);
                    } else {
                        int actualRestockQuantity = Math.min(quantity, remainingCapacity);
                        itemInventory.addItem(actualRestockQuantity);
                        outputTextArea.append(actualRestockQuantity + " pieces of " + itemName + " restocked.\n");
                        isValid = true;
                    }
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(this, "Invalid input! Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
        outputTextArea.append("Items restocked successfully.\n\n");
    }

    /**
     * Allows setting the price for an item in the vending machine inventory.
     * The method prompts the user to input the slot number of the item for which the price needs to be set.
     * Then, the user is prompted to input the new price for the selected item.
     * The new price must be a valid positive number.
     * If the user cancels setting the price for any step, the method exits without making any changes.
     *
     * @param outputTextArea The JTextArea used to display the output and messages to the user.
     */
    private void setItemPrice(JTextArea outputTextArea) {
        boolean isValid = false;

        while (!isValid) {
            String slotNumberInput = JOptionPane.showInputDialog(this, "Enter the slot number to set the price: ", "Slot Number of Item", JOptionPane.PLAIN_MESSAGE);

            if (slotNumberInput == null) {
                // User clicked the "Cancel" button
                outputTextArea.append("Setting of item price cancelled.\n\n");
                return; // Exit the method without making any changes
            }

            try {
                int slotNumber = Integer.parseInt(slotNumberInput);
                if (slotNumber >= 1 && slotNumber <= vendingMachine.getInventory().size()) {
                    int selectedIndex = slotNumber - 1;
                    Inventory selectedInventory = vendingMachine.getInventory().get(selectedIndex);
                    Item item = selectedInventory.getItem();

                    String newPriceInput = JOptionPane.showInputDialog(this, "Enter the new price for " + item.getName() + ": ", "Set Item Price", JOptionPane.PLAIN_MESSAGE);

                    if (newPriceInput == null) {
                        // User clicked the "Cancel" button
                        outputTextArea.append("Setting of item price for " + item.getName() + " cancelled.\n\n");
                        return; // Exit the method without making any changes
                    }

                    try {
                        double newPrice = Double.parseDouble(newPriceInput);
                        item.setPrice(newPrice);
                        if (newPrice <= 0) {
                            // User entered an invalid price (zero or negative)
                            outputTextArea.append("Setting of item price for " + item.getName() + " cancelled.\n\n");
                            return; // Exit the method without making any changes
                        } 
                        outputTextArea.append("Price for " + item.getName() + " updated successfully.\n\n");
                        isValid = true; // Set isValid to true to exit the loop
                    } catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(this, "Invalid input! Please enter a valid price.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid Slot Number.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid input! Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    /**
     * Allows refilling the change in the vending machine by adding more denominations of coins or bills.
     * The method prompts the user to input the quantity to refill for each denomination.
     * The input quantity must be a positive number, and the refill is done in the denomination's respective currency.
     * If the user cancels refilling for any denomination, the method skips to the next denomination.
     *
     * @param outputTextArea The JTextArea used to display the output and messages to the user.
     */
    private void makeChange(JTextArea outputTextArea) {
        StringBuilder changeOutput = new StringBuilder();

        changeOutput.append("Change refill:\n");

        // Loop through the accepted denominations of coins or bills
        for (Map.Entry<Double, Denomination> entry : vendingMachine.getAcceptedCash().entrySet()) {
            boolean isValid = false;
            while (!isValid) {
                String input = JOptionPane.showInputDialog(this, "Enter the quantity to refill for Php" + entry.getKey() + ": ", "Refill Money for Change", JOptionPane.PLAIN_MESSAGE);

                if (input == null) {
                    // User clicked the "Cancel" button, skip to the next amount
                    outputTextArea.append("Refill for Php" + entry.getKey() + " canceled.\n");
                    break;
                }

                try {
                    int quantity = Integer.parseInt(input);
                    if (quantity < 0) {
                        JOptionPane.showMessageDialog(this, "Invalid input! Please enter a positive quantity.", "Error", JOptionPane.ERROR_MESSAGE);
                    } else {
                        entry.getValue().setQuantity(entry.getValue().getQuantity() + quantity);
                        outputTextArea.append("Php " + entry.getKey() + " refilled successfully.\n");
                        isValid = true; // Move to the next denomination
                    }
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(this, "Invalid input! Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
            changeOutput.setLength(0); // Clear the StringBuilder for the next denomination
        }
    }

    /**
     * Collects the total sales amount from the vending machine and displays it in the outputTextArea.
     * If there are no transactions (total sales amount is zero), it informs the user that there is no amount to collect.
     *
     * @param outputTextArea The JTextArea used to display the output and messages to the user.
     */
    private void collectPayment(JTextArea outputTextArea) {
        // Get the total sales amount from the vending machine
        double totalSales = vendingMachine.getTotalSales();
    
        if (totalSales == 0) {
            outputTextArea.append("No amount to collect. There are no transactions.\n\n");
            return;
        }
    
        outputTextArea.append("Amount to Collect: Php " + totalSales + "\n");
    }
    
    /**
     * Handles the process of purchasing a custom drink from the vending machine.
     *
     * @param outputTextArea The JTextArea used to display the output and messages to the user.
     */
    private void purchaseItem(JTextArea outputTextArea) {
        // Create the purchase panel with input fields for customizing the drink
        JPanel purchasePanel = new JPanel(new GridLayout(0, 2, 10, 10));
        purchasePanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    
        // Drink selection
        JLabel drinkLabel = new JLabel("Select a Drink:");
        String[] drinkOptions = {"White Chocolate Coffee", "Caramel Macchiato"};
        JComboBox<String> drinkComboBox = new JComboBox<>(drinkOptions);
        purchasePanel.add(drinkLabel);
        purchasePanel.add(drinkComboBox);
    
        // Cup Size selection
        JLabel cupSizeLabel = new JLabel("Select Cup Size:");
        String[] cupSizeOptions = {"Small", "Medium", "Large"};
        JComboBox<String> cupSizeComboBox = new JComboBox<>(cupSizeOptions);
        purchasePanel.add(cupSizeLabel);
        purchasePanel.add(cupSizeComboBox);
    
        // Temperature selection
        JLabel temperatureLabel = new JLabel("Select Temperature:");
        String[] temperatureOptions = {"Hot", "Iced"};
        JComboBox<String> temperatureComboBox = new JComboBox<>(temperatureOptions);
        purchasePanel.add(temperatureLabel);
        purchasePanel.add(temperatureComboBox);
    
        // Sugar Level selection
        JLabel sugarLevelLabel = new JLabel("Select Sugar Level:");
        String[] sugarLevelOptions = {"No Sugar", "With Sugar"};
        JComboBox<String> sugarLevelComboBox = new JComboBox<>(sugarLevelOptions);
        purchasePanel.add(sugarLevelLabel);
        purchasePanel.add(sugarLevelComboBox);
    
        // Milk Choice selection
        JLabel milkChoiceLabel = new JLabel("Select Milk Choice:");
        String[] milkChoiceOptions = {"Cow Milk", "Soy Milk", "Almond Milk"};
        JComboBox<String> milkChoiceComboBox = new JComboBox<>(milkChoiceOptions);
        purchasePanel.add(milkChoiceLabel);
        purchasePanel.add(milkChoiceComboBox);
    
        // Espresso Shots selection
        JLabel espressoShotsLabel = new JLabel("Select Espresso Shots:");
        JRadioButton noEspressoRadioButton = new JRadioButton("0 Espresso Shots");
        JRadioButton oneEspressoRadioButton = new JRadioButton("1 Espresso Shot");
        JRadioButton twoEspressoRadioButton = new JRadioButton("2 Espresso Shots");

        ButtonGroup espressoShotsGroup = new ButtonGroup();
        espressoShotsGroup.add(noEspressoRadioButton);
        espressoShotsGroup.add(oneEspressoRadioButton);
        espressoShotsGroup.add(twoEspressoRadioButton);

        JPanel espressoShotsPanel = new JPanel(new GridLayout(0, 1));
        espressoShotsPanel.add(espressoShotsLabel);
        espressoShotsPanel.add(noEspressoRadioButton);
        espressoShotsPanel.add(oneEspressoRadioButton);
        espressoShotsPanel.add(twoEspressoRadioButton);
        purchasePanel.add(espressoShotsPanel);
    
        // Amount Paid input and label
        JLabel amountPaidLabel = new JLabel("Enter the amount to pay:");
        JTextField amountPaidTextField = new JTextField();
        // Panels to hold label and text field
        JPanel amountPaidPanel = new JPanel(new GridBagLayout());
        GridBagConstraints amountPaidConstraints = new GridBagConstraints();

        amountPaidConstraints.anchor = GridBagConstraints.WEST;
        amountPaidConstraints.insets = new Insets(5, 5, 5, 5);
        amountPaidConstraints.gridx = 0;
        amountPaidConstraints.gridy = 0;
        amountPaidPanel.add(amountPaidLabel, amountPaidConstraints);

        amountPaidConstraints.anchor = GridBagConstraints.WEST; 
        amountPaidConstraints.gridx = 1;
        amountPaidConstraints.gridy = 0;
        amountPaidPanel.add(amountPaidTextField, amountPaidConstraints);

        amountPaidTextField.setPreferredSize(new Dimension(150, 30));

        purchasePanel.add(new JPanel()); 
        purchasePanel.add(amountPaidPanel); 

        // Display the purchase panel as a dialog and wait for user input
        int result = JOptionPane.showConfirmDialog(this, purchasePanel, "Purchase Item", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            // Get the user input for amount paid
            double amountPaid;
            try {
                amountPaid = Double.parseDouble(amountPaidTextField.getText());
            } catch (NumberFormatException ex) {
                outputTextArea.append("Invalid amount. Please enter a valid number.\n");
                return;
            }
            
            // Get the selected items 
            int drinkChoice = drinkComboBox.getSelectedIndex();
            if (drinkChoice < 0) {
                outputTextArea.append("Please select a drink.\n");
                return;
            }
    
            String drinkName = getDrinkNameByChoice(drinkChoice);
            if (drinkName == null) {
                outputTextArea.append("Invalid drink choice. Purchase canceled.\n");
                return;
            }
    
            String cupSize = (String) cupSizeComboBox.getSelectedItem();
            String temperature = (String) temperatureComboBox.getSelectedItem();
            String sugarLevel = (String) sugarLevelComboBox.getSelectedItem();
            String milkChoice = (String) milkChoiceComboBox.getSelectedItem();
            int numEspressoShots = 0;

            if (oneEspressoRadioButton.isSelected()) {
                numEspressoShots = 1;
            } else if (twoEspressoRadioButton.isSelected()) {
                numEspressoShots = 2;
            }
            
            // Create a CustomDrink object with the selected options
            CustomDrink customDrink = new CustomDrink(drinkName);
            customDrink.setCupSize(cupSize);
            customDrink.setTemperature(temperature);
            customDrink.setSugarLevel(sugarLevel);
            customDrink.setMilkChoice(milkChoice);
            customDrink.setNumEspressoShots(numEspressoShots);

            // Calculate the total calories and total price for the custom drink
            int totalCalories = vendingMachine.calculateTotalCalories(customDrink);
            double totalPrice = vendingMachine.calculateTotalPrice(customDrink);
            
            // Check if the amount paid is sufficient for the purchase
            if (amountPaid < totalPrice) {
                outputTextArea.append("Insufficient payment. Purchase canceled.\n");
                return;
            }
    
            // Display the order summary for confirmation
            result = JOptionPane.showConfirmDialog(this, getOrderSummary(customDrink, totalCalories, totalPrice) + "Confirm purchase?", "Confirm Purchase", JOptionPane.YES_NO_OPTION);
            if (result == JOptionPane.YES_OPTION) { // If the purchase is confirmed, proceed with the transaction
                // Display the preparation message
                displayPrepareDrinkMessage(customDrink);
                outputTextArea.append("Drink prepared and purchased successfully.\n\n");
                
                // Calculate and display the change returned to the customer
                double change = amountPaid - totalPrice;
                // Update the vending machine's sales and inventory based on the purchased drink
                vendingMachine.addToSales(totalPrice);
                vendingMachine.incrementCustomizedDrinksCount(); // Increment the count of customized drinks
                outputTextArea.append("Change: Php " + change + "\n");
                outputTextArea.append("Thank you for your purchase!\n\n");

                if (drinkName == "White Chocolate Coffee") {
                    reduceInventoryQuantity("White Chocolate Powder", totalCalories);
                } else if (drinkName == "Caramel Macchiato") {
                    reduceInventoryQuantity("Caramel Macchiato Powder", 1);
                }
                
                if (cupSize == "Small"){
                    reduceInventoryQuantity("Cup - Small", 1);
                } else if (cupSize == "Medium") {
                    reduceInventoryQuantity("Cup - Medium", 1);
                } else if (cupSize == "Large") {
                    reduceInventoryQuantity("Cup - Large", 1);
                }

                if (temperature == "Iced") {
                    reduceInventoryQuantity("Ice", 1);
                }

                if (numEspressoShots == 1) {
                    reduceInventoryQuantity("Espresso", 1);
                } else if (numEspressoShots == 2) {
                    reduceInventoryQuantity("Espresso", 2);
                }
                reduceInventoryQuantity(milkChoice, 1);
            } else {
                outputTextArea.append("Purchase canceled.\n\n");
            }
        } else {
            outputTextArea.append("Purchase canceled.\n\n");
        }
    }

    /**
     * Reduces the quantity of a specific item in the vending machine's inventory.
     *
     * @param itemName The name of the item to reduce.
     * @param quantity The quantity to be reduced.
     */
    private void reduceInventoryQuantity(String itemName, int quantity) {
        // Get the index of the selected item in the inventory
        int selectedIndex = getItemIndexByName(itemName);
        if (selectedIndex < 0 || selectedIndex >= vendingMachine.getInventory().size()) {
            outputTextArea.append("Invalid selection for \"" + itemName + "\". Purchase canceled.\n");
            return;
        }

        // Get the selected inventory item and check its availability
        Inventory selectedInventory = vendingMachine.getInventory().get(selectedIndex);
        int remainingQuantity = selectedInventory.getQuantity();
        if (remainingQuantity < quantity) {
            outputTextArea.append("Not enough stock for \"" + itemName + "\". Purchase canceled.\n");
            return;
        }

        // Reduce the quantity of the selected item in the inventory
        selectedInventory.decrementQuantity();
    }

    /**
     * Finds the index of a specific item in the vending machine's inventory based on its name.
     *
     * @param itemName The name of the item to search for.
     * @return The index of the item in the inventory, or -1 if the item is not found.
     */
    private int getItemIndexByName(String itemName) {
        for (int i = 0; i < vendingMachine.getInventory().size(); i++) {
            Item item = vendingMachine.getInventory().get(i).getItem();
            if (item.getName().equals(itemName)) {
                return i; // Returns index if found
            }
        }
        return -1; // Item with the given name not found in the inventory
    }

    /**
     * Displays the current inventory of the vending machine in the output text area.
     *
     * @param outputTextArea The JTextArea where the inventory will be displayed.
     */
    private void displayInventory(JTextArea outputTextArea) {
        outputTextArea.append("Slot\tItem Name\tPrice\t\tQuantity\n");
        for (int i = 0; i < vendingMachine.getInventory().size(); i++) {
            Inventory itemInventory = vendingMachine.getInventory().get(i);
            Item item = itemInventory.getItem();
            String itemName = item.getName();
            double itemPrice = item.getPrice();
            int quantity = itemInventory.getQuantity();
            String slotLabel = "[" + (i + 1) + "]";
            String quantityLabel = (quantity > 0) ? String.valueOf(quantity) : "Out of stock";
            outputTextArea.append(String.format("%-8s%-16sPhp%8.2f    %s%n", slotLabel, itemName, itemPrice, quantityLabel));
        }
        outputTextArea.append("\n");
    }

    /**
     * Prints a summary of the transaction history in the output text area.
     *
     * @param outputTextArea The JTextArea where the transaction summary will be displayed.
     */
    public void printTransactionSummary(JTextArea outputTextArea) {
        // Calculate the total number of drinks customized
        int customizedDrinksCount = vendingMachine.getCustomizedDrinksCount();

        // Create the transaction history message
        StringBuilder message = new StringBuilder("Transaction History:\n");
        // Append the count of customized drinks to the message
        message.append("Total Customized Drinks Made: ").append(customizedDrinksCount).append("\n");
        message.append("Total Sales Amount: Php ").append(String.format("%.2f", vendingMachine.getTotalSales())).append("\n\n");

        // Append the message to the outputTextArea
        outputTextArea.append(message.toString());
    }
}

import java.util.List;

/**
 * The Transaction class represents a transaction made at the vending machine.
 * It holds information about the list of items purchased and the amount paid by the customer.
 * 
 * @author Genelle Chua
 * @author Angela Tobias
 * @version 24.0
 */
public class Transaction {
    // Declare class attributes 
    private List<Item> items; // List of items purchased in the transaction
    private double amountPaid; // Amount paid by the customer for the transaction

    /**
     * Constructs a new Transaction object with the provided list of items and amount paid.
     *
     * @param items      The list of items purchased in the transaction.
     * @param amountPaid The amount paid by the customer for the transaction.
     */
    public Transaction(List<Item> items, double amountPaid) {
        this.items = items;
        this.amountPaid = amountPaid;
    }

    /**
     * Gets the list of items purchased in the transaction.
     *
     * @return The list of items purchased.
     */
    public List<Item> getItems() {
        return items;
    }

    /**
     * Gets the quantity of items purchased in the transaction.
     *
     * @return The number of items purchased.
     */
    public int getQuantity() {
        return items.size();
    }

    /**
     * Gets the amount paid by the customer for the transaction.
     *
     * @return The amount paid.
     */
    public double getAmountPaid() {
        return amountPaid;
    }
}

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class VendingMachineGUI extends JFrame {
    private Map<String, Double> itemPrices; // Inventory with item names and prices
    private Map<String, Integer> itemStocks; // Inventory with item names and available stocks
    private List<JButton> itemButtons;
    private JButton purchaseButton;
    private JButton adminButton; // Button to access the admin panel
    private JLabel displayLabel;

    private double totalSales;

    // Admin Panel Components
    private JFrame adminFrame;
    private JTable inventoryTable;
    private DefaultTableModel inventoryTableModel;
    private JButton restockButton;

    public VendingMachineGUI() {
        setTitle("Vending Machine");
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Initialize components
        itemButtons = new ArrayList<>();
        itemPrices = new HashMap<>();
        itemPrices.put("Item 1", 1.5);
        itemPrices.put("Item 2", 2.0);
        // Add more items to the inventory

        itemStocks = new HashMap<>();
        itemStocks.put("Item 1", 5); // Initial stock for each item
        itemStocks.put("Item 2", 7); // Initial stock for each item
        // Add more items to the inventory

        purchaseButton = new JButton("Purchase");
        displayLabel = new JLabel("Select an item:");

        // Add action listener to the purchase button
        purchaseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Perform the purchase logic here
                String selectedItem = displayLabel.getText().replace("Selected item: ", "");
                if (!selectedItem.isEmpty()) {
                    double price = itemPrices.getOrDefault(selectedItem, 0.0);
                    int stock = itemStocks.getOrDefault(selectedItem, 0);
                    if (stock > 0 && price > 0.0) {
                        double amountPaid = promptForPayment(price);
                        if (amountPaid >= price) {
                            double change = amountPaid - price;
                            totalSales += price;
                            displayLabel.setText("Selected item: " + selectedItem + " (Change: $" + change + ")");
                            itemStocks.put(selectedItem, stock - 1); // Reduce the stock
                        } else {
                            displayLabel.setText("Not enough money for " + selectedItem + ". Please insert more.");
                        }
                    } else {
                        displayLabel.setText("Out of stock for " + selectedItem + ". Please select another item.");
                    }
                }
            }
        });

        // Create the item buttons
        for (String itemName : itemPrices.keySet()) {
            JButton itemButton = new JButton(itemName);
            itemButtons.add(itemButton);
            itemButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Perform the item selection logic here
                    // For example, update the display label with the selected item
                    displayLabel.setText("Selected item: " + itemButton.getText());
                }
            });
        }

        // Add components to the layout
        JPanel itemPanel = new JPanel(new GridLayout(3, 3));
        for (JButton itemButton : itemButtons) {
            itemPanel.add(itemButton);
        }

        JPanel controlPanel = new JPanel(new FlowLayout());
        controlPanel.add(purchaseButton);

        // Add an admin button to access the admin panel
        adminButton = new JButton("Admin");
        adminButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openAdminPanel();
            }
        });
        controlPanel.add(adminButton);

        add(displayLabel, BorderLayout.NORTH);
        add(itemPanel, BorderLayout.CENTER);
        add(controlPanel, BorderLayout.SOUTH);
    }

    private double promptForPayment(double price) {
        String input = JOptionPane.showInputDialog(this, "Please insert $" + price + " for payment:");
        if (input == null || input.isEmpty()) {
            return 0.0;
        } else {
            try {
                return Double.parseDouble(input);
            } catch (NumberFormatException e) {
                return 0.0;
            }
        }
    }

    // Method to open the admin panel
    private void openAdminPanel() {
        adminFrame = new JFrame("Admin Panel");
        adminFrame.setSize(400, 300);
        adminFrame.setLayout(new BorderLayout());

        // Create the inventory table
        String[] columnNames = {"Item Name", "Price ($)", "Stock"};
        inventoryTableModel = new DefaultTableModel(columnNames, 0);
        inventoryTable = new JTable(inventoryTableModel);
        updateInventoryTable();

        JScrollPane scrollPane = new JScrollPane(inventoryTable);
        adminFrame.add(scrollPane, BorderLayout.CENTER);

        // Create the restock button
        restockButton = new JButton("Restock");
        restockButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Perform restocking logic here
                int selectedRow = inventoryTable.getSelectedRow();
                if (selectedRow != -1) {
                    String itemName = inventoryTableModel.getValueAt(selectedRow, 0).toString();
                    int currentStock = itemStocks.getOrDefault(itemName, 0);
                    int additionalStock = promptForRestock(itemName);
                    itemStocks.put(itemName, currentStock + additionalStock);
                    updateInventoryTable();
                }
            }
        });

        adminFrame.add(restockButton, BorderLayout.SOUTH);

        adminFrame.setVisible(true);
    }

    private int promptForRestock(String itemName) {
        String input = JOptionPane.showInputDialog(adminFrame, "Enter the additional stock for " + itemName + ":");
        if (input == null || input.isEmpty()) {
            return 0;
        } else {
            try {
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                return 0;
            }
        }
    }

    // Method to update the inventory table with current item prices and stocks
    private void updateInventoryTable() {
        inventoryTableModel.setRowCount(0);
        for (String itemName : itemPrices.keySet()) {
            double price = itemPrices.get(itemName);
            int stock = itemStocks.getOrDefault(itemName, 0);
            inventoryTableModel.addRow(new Object[]{itemName, price, stock});
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new VendingMachineGUI().setVisible(true);
            }
        });
    }
}

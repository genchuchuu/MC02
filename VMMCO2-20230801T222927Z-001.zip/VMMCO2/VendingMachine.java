import java.util.*;

abstract class VendingMachine {
    
    protected List<Inventory> inventory;
    protected Map<Double, Denomination> acceptedCash;
    protected List<Item> sales;
    protected double totalSales;

    public VendingMachine(List<Inventory> inventory, Map<Double, Denomination> acceptedCash) {
        this.inventory = inventory;
        this.acceptedCash = acceptedCash;
        sales = new ArrayList<>();
        totalSales = 0.0;
    }

    public abstract void testMaintenanceFeatures();


    public abstract void testVendingFeatures();

    public void purchaseItem(Scanner scanner) {
        System.out.print("Enter the slot number to purchase the item: ");
        int slotNumber = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        if (slotNumber >= 1 && slotNumber <= inventory.size()) {
            Inventory item = inventory.get(slotNumber - 1);
            if (item.getQuantity() > 0) {
                double amountPaid = acceptPayment(scanner, item.getItem().getPrice());
                if (amountPaid > 0) {
                    item.decrementQuantity();
                    addToSales(item.getItem().getPrice());
                    dispenseItem(slotNumber);
                    produceChange(scanner, amountPaid - item.getItem().getPrice());
                    System.out.println("Item purchased successfully.");
                } else {
                    System.out.println("Purchase canceled. Insufficient payment.");
                }
            } else {
                System.out.println("Purchase failed. Item not available.");
            }
        } else {
            System.out.println("Invalid slot number.");
        }
    }

    protected void dispenseItem(int slotNumber) {
        Inventory item = inventory.get(slotNumber - 1);
        System.out.println("Dispensed item: " + item.getItem().getName());
    }

    protected void testMaintenanceFeatures(Scanner scanner, VendingMachine vendingMachine) {
        System.out.println("\nMaintenance Testing Mode");
    
        if (vendingMachine instanceof SpecialVendingMachine) {
            System.out.println("Current Add-On Item Quantities:");
            SpecialVendingMachine specialMachine = (SpecialVendingMachine) vendingMachine;
    
            // Define the restockItems map here
            Map<String, Integer> restockItems = new HashMap<>();
    
            for (Inventory inventoryItem : specialMachine.getInventory()) {
                System.out.print("Enter the quantity to restock for " + inventoryItem.getItem().getName() + ": ");
                int quantity = scanner.nextInt();
                scanner.nextLine(); // Consume the newline character
                restockItems.put(inventoryItem.getItem().getName(), quantity);
            }
    
            specialMachine.restockAddOnItems(restockItems);
        }
    
        System.out.println("\nMaintenance Testing Complete.");
    }

    public void restockAddOnItems(Map<String, Integer> restockItems) {
        for (Map.Entry<String, Integer> entry : restockItems.entrySet()) {
            String itemName = entry.getKey();
            int quantityToAdd = entry.getValue();

            boolean itemFound = false;
            for (Inventory inventoryItem : inventory) {
                if (inventoryItem.getItem().getName().equals(itemName)) {
                    inventoryItem.addQuantity(quantityToAdd);
                    itemFound = true;
                    if (quantityToAdd > 0) {
                        System.out.println(quantityToAdd + " units of " + itemName + " added to the inventory.");
                    } else if (quantityToAdd < 0) {
                        System.out.println(-quantityToAdd + " units of " + itemName + " removed from the inventory.");
                    } else {
                        System.out.println("No change in inventory for " + itemName + ".");
                    }
                    break;
                }
            }

            if (!itemFound) {
                System.out.println("Item " + itemName + " not found in the inventory. Restocking failed.");
            }
        }
    }
    
    protected double acceptPayment(Scanner scanner, double requiredAmount) {
        System.out.print("Enter the amount to pay (or 0 to cancel): ");
        double amountPaid = scanner.nextDouble();
        scanner.nextLine(); // Consume the newline character

        if (amountPaid < requiredAmount) {
            System.out.println("Insufficient payment. Please pay the correct amount.");
            return 0.0;
        } else {
            double change = amountPaid - requiredAmount;
            System.out.println("Payment successful. Change: " + change);
            return change;
        }
    }

    protected void addToSales(double itemPrice) {
        totalSales += itemPrice;
    }
    

    protected void produceChange(Scanner scanner, double amount) {
        List<Double> availableDenominations = new ArrayList<>(acceptedCash.keySet());
        Collections.sort(availableDenominations, Collections.reverseOrder());
    
        Map<Double, Integer> changeToDispense = new HashMap<>();
    
        double remainingAmount = amount;
        for (double denomination : availableDenominations) {
            int numNotes = (int) (remainingAmount / denomination);
            if (numNotes > 0) {
                Denomination denominationObj = acceptedCash.get(denomination);
                int availableQuantity = denominationObj.getQuantity();
    
                if (availableQuantity >= numNotes) {
                    changeToDispense.put(denomination, numNotes);
                    remainingAmount -= (denomination * numNotes);
                } else {
                    // If there are not enough notes of this denomination, use available quantity
                    changeToDispense.put(denomination, availableQuantity);
                    remainingAmount -= (denomination * availableQuantity);
                }
            }
        }
    
        if (remainingAmount == 0.0) {
            System.out.println("Change produced successfully: " + amount);
            dispenseChange(changeToDispense);
        } else {
            System.out.println("Insufficient change. Please try again later.");
        }
    }
    

    protected void dispenseChange(Map<Double, Integer> changeToDispense) {
        System.out.println("Dispensing change with the following denominations...");
        for (Map.Entry<Double, Integer> entry : changeToDispense.entrySet()) {
            double denomination = entry.getKey();
            int numNotes = entry.getValue();
            System.out.println(numNotes + " x Php " + denomination);
            acceptedCash.get(denomination).decrementQuantity(numNotes);
        }
    }

    protected void setItemPrice(Scanner scanner) {
        System.out.print("Enter the slot number to set the price: ");
        int slotNumber = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        if (slotNumber >= 1 && slotNumber <= inventory.size()) {
            Inventory item = inventory.get(slotNumber - 1);
            System.out.print("Enter the new price: ");
            double newPrice = scanner.nextDouble();
            scanner.nextLine(); // Consume the newline character

            item.getItem().setPrice(newPrice);
            System.out.println("Price updated successfully.");
        } else {
            System.out.println("Invalid slot number.");
        }
    }

    protected abstract void collectPayment();

    public void printTransactionSummary() {
        System.out.println("Transaction Summary:");
        for (Item item : sales) {
            System.out.println("Item: " + item.getName() + " - Price: " + item.getPrice());
        }
        System.out.println("Total Sales: " + totalSales);
    }

    protected abstract void calculateTotalInventory();
    protected void addItemToInventory(Item item, int quantity) {
        if (quantity < 0) {
            throw new IllegalArgumentException("Quantity must be non-negative.");
        }
        inventory.add(new Inventory(item, quantity));
    }
    
    protected void displayAcceptedCash() {
        System.out.println("Accepted Denominations:");
        for (Map.Entry<Double, Denomination> entry : acceptedCash.entrySet()) {
            double denomination = entry.getKey();
            Denomination denominationObj = entry.getValue();
            int quantity = denominationObj.getQuantity();
            System.out.println("Php " + denomination + ": " + quantity);
        }
    }

    public List<Inventory> getInventory() {
        return inventory;
    }

    protected void restockItems(Scanner scanner) {
        System.out.println("\nCurrent Inventory:");
        displayInventory();

        for (Inventory itemInventory : inventory) {
            System.out.print("Enter the quantity to restock for 10 up to 15 pieces only " + itemInventory.getItem().getName() + ": ");
            int quantity = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character
            
            if (itemInventory.getQuantity() == 11) {
                System.out.println("Maximum inventory of " + 11 + " reached for " + itemInventory.getItem().getName() + ". Restocking not allowed.");
                System.out.print("Do you want to cancel restocking? (Y/N): ");
                String input = scanner.nextLine().trim().toLowerCase();

                if (input.equals("y")) {
                    System.out.println("Restocking canceled.");
                    return;
                }
            }

            while (quantity < 10 || quantity > 15) {
                System.out.println("Invalid input! Please try again");
                System.out.print("Enter the quantity to restock for " + itemInventory.getItem().getName() + ": ");
                quantity = scanner.nextInt();
                scanner.nextLine(); // Consume the newline character
            }

            itemInventory.addItem(quantity);
        }

        System.out.println("Items restocked successfully.");
    }

    public boolean hasSufficientChange(double amount) {
        List<Double> availableDenominations = new ArrayList<>(acceptedCash.keySet());
        Collections.sort(availableDenominations, Collections.reverseOrder());
    
        double remainingAmount = amount;
        for (double denomination : availableDenominations) {
            int numNotes = (int) (remainingAmount / denomination);
            if (numNotes > 0) {
                Denomination denominationObj = acceptedCash.get(denomination);
                if (denominationObj.getQuantity() >= numNotes) {
                    remainingAmount -= (denomination * numNotes);
                } else {
                    // If there are not enough notes of this denomination, return false
                    return false;
                }
            }
        }
    
        // If the remaining amount is zero, it means we can form the change using available denominations
        return remainingAmount == 0.0;
    }
    

    // New method for displaying the inventory
    protected void displayInventory() {
        System.out.println("Slot\tItem Name\tPrice\t\tQuantity");
        for (int i = 0; i < inventory.size(); i++) {
            Inventory itemInventory = inventory.get(i);
            Item item = itemInventory.getItem();
            String itemName = item.getName();
            double itemPrice = item.getPrice();
            int quantity = itemInventory.getQuantity();
            String slotLabel = "[" + (i + 1) + "]";
            String quantityLabel = (quantity > 0) ? String.valueOf(quantity) : "Out of stock";
            System.out.printf("%-8s%-16sPhp%8.2f    %s%n", slotLabel, itemName, itemPrice, quantityLabel);
        }
    }

    public void addChange(Denomination changeDenomination) {
    }
}
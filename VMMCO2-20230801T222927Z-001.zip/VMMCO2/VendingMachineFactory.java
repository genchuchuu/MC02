import java.util.*;

public class VendingMachineFactory {
    private static final int MAX_VM = 4;
    private static final int MAX_ITEMS = 8;

    public static void main(String[] args) {
        VendingMachineFactory factory = new VendingMachineFactory();
        factory.start();
    }

    public void start() {
        List<VendingMachine> vendingMachines = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n\nWELCOME TO THIRSTY DRINKY FACTORY\n\n");
            System.out.println("Menu:");
            System.out.println("[1] Create a Regular Vending Machine");
            System.out.println("[2] Create a Special Vending Machine");
            System.out.println("[3] About the Vending Machine");
            System.out.println("[4] Exit");

            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();
            int quantity = 0;
    
            while (true) {
                System.out.print("Enter the quantity of vending machines to create (1-4): ");
                quantity = scanner.nextInt();
                scanner.nextLine();
                if (quantity >= 1 && quantity <= MAX_VM) {
                    break;
                }
                System.out.println("Invalid quantity. Please try again.");
            }
    
            switch (choice) {
                case 1:
                    for (int i = 0; i < quantity; i++) {
                        RegularVendingMachine regularVendingMachine = createRegularVendingMachine(scanner);
                        vendingMachines.add(regularVendingMachine);
                        // Increment vendingMachineCount here if you want to use it later
                    }
                    for (int i = 0; i < vendingMachines.size(); i++) {
                        int choose = 0;
                        while (choose != 3) {
                            System.out.println("Choose to test vending machine " + (i + 1) + ": (Choose maintenance First to Set-up)");
                            System.out.println("[1] Test Maintenance");
                            System.out.println("[2] Test Actual Vending Machine");
                            System.out.println("[3] Exit");
                            System.out.print("Enter your choice: ");
                            choose = scanner.nextInt();
                            scanner.nextLine();
    
                            if (choose == 1) {
                                vendingMachines.get(i).testMaintenanceFeatures();
                            } else if (choose == 2) {
                                vendingMachines.get(i).testVendingFeatures();
                            } else if (choose == 3) {
                                break;
                            } else {
                                System.out.println("Invalid Input! Please try again");
                            }
                        }
                    }
                    break;
                case 2:
                    for (int i = 0; i < quantity; i++) {
                        SpecialVendingMachine specialVendingMachine = createSpecialVendingMachine(scanner);
                        vendingMachines.add(specialVendingMachine);
                        // Increment vendingMachineCount here if you want to use it later
                    }
                    for (int i = 0; i < vendingMachines.size(); i++) {
                        int chooseSpecial = 0;
                        while (chooseSpecial != 3) {
                            System.out.println("Choose to test vending machine " + (i + 1) + ": (Choose maintenance First to Set-up)");
                            System.out.println("[1] Test Maintenance");
                            System.out.println("[2] Test Actual Vending Machine");
                            System.out.println("[3] Exit");
                            System.out.print("Enter your choice: ");
                            chooseSpecial = scanner.nextInt();
                            scanner.nextLine();
    
                            if (chooseSpecial == 1) {
                                vendingMachines.get(i).testMaintenanceFeatures();
                            } else if (chooseSpecial == 2) {
                                vendingMachines.get(i).testVendingFeatures();
                            } else if (chooseSpecial == 3) {
                                break;
                            } else {
                                System.out.println("Invalid Input! Please try again");
                            }
                        }
                    }
                    break;
                case 3:
                    displayAboutPage(scanner);
                    break;
                case 4:
                    System.out.println("Exiting the program...");
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private void displayAboutPage(Scanner scanner) {
        System.out.println("\nAbout the Program\n\n");

        System.out.println("Hello! We are ThirstyDrinky! We are a company that offers vending machines");
        System.out.println("for beverages. We have regular vending machines consisting of");
        System.out.println("simple drinks such as water, juices, and milk. We also offer special");
        System.out.println("vending machines that allow customers to customize their coffee drinks.");
        System.out.println("We hope to satisfy your needs in creating a vending machine.");
        System.out.println("Thank you!\n");

        System.out.print("Type [1] to go back to the Main Menu: ");
        int back = scanner.nextInt();
        scanner.nextLine();

        while (back != 1) {
            System.out.println("Invalid Input! Please try again");
            System.out.print("\n\nType [1] to go back to the Main Menu: ");
            back = scanner.nextInt();
            scanner.nextLine();
        }
    }

    public RegularVendingMachine createRegularVendingMachine(Scanner scanner) {
        List<Inventory> inventory = new ArrayList<>();
        Map<Double, Denomination> acceptedCash = new HashMap<>();
        List<String> chosenItems = new ArrayList<>();

        System.out.println("Select 8 products to add to the vending machine:");
        System.out.println("ID\tProduct\t\tPrice\t\tCalories(250ml)");
        System.out.println("[1]\tWater\t\t20\t\t0");
        System.out.println("[2]\tIced tea\t30\t\t95");
        System.out.println("[3]\tApple juice\t35\t\t118");
        System.out.println("[4]\tOrange juice\t35\t\t118");
        System.out.println("[5]\tGrape juice\t35\t\t161");
        System.out.println("[6]\tCoconut juice\t35\t\t48");
        System.out.println("[7]\tLemon juice\t40\t\t59");
        System.out.println("[8]\tCow milk\t45\t\t109");
        System.out.println("[9]\tCoconut Milk\t45\t\t575");
        System.out.println("[10]\tMatcha\t\t60\t\t68");
        System.out.println("[11]\tSoy Milk\t60\t\t135");
        System.out.println("[12]\tAlmond Milk\t75\t\t43");

        for (int i = 0; i < MAX_ITEMS; i++) {
            int productChoice;
            boolean validChoice = false;

            while (!validChoice) {
                System.out.print("Enter the ID for product of slot " + (i + 1) + ": ");
                productChoice = scanner.nextInt();
                scanner.nextLine();

                String product = getProductByChoice(productChoice);
                if (product == null) {
                    System.out.println("Invalid choice. Please try again.");
                } else if (chosenItems.contains(product)) {
                    System.out.println("You have already chosen that item. Please choose a different one.");
                } else {
                    chosenItems.add(product);
                    inventory.add(new Inventory(new Item(product, getPriceByChoice(productChoice), getCaloriesByChoice(productChoice)), 0));
                    validChoice = true;
                }
            }
        }

    acceptedCash.put(0.10, new Denomination(0.5));
    acceptedCash.put(0.25, new Denomination(0.10));
    acceptedCash.put(0.50, new Denomination(0.75));
    acceptedCash.put(0.75, new Denomination(0.25));
    acceptedCash.put(5.0, new Denomination(5));
    acceptedCash.put(10.0, new Denomination(10));
    acceptedCash.put(20.0, new Denomination(20));
    acceptedCash.put(50.0, new Denomination(50));
    acceptedCash.put(100.0, new Denomination(100));
    acceptedCash.put(500.0, new Denomination(500));

    return new RegularVendingMachine(inventory, acceptedCash);
    }
    private Inventory createVanillaSyrup() {
        double price = 50.0;
        int calories = 100;
        String description = "Vanilla Syrup";
        return new Inventory(new Item(description, price, calories), 0); // Change the quantity as required
    }

    private Inventory createCups(String size) {
        double price = 5.0;
        int calories = 0;
        String description = "Cup - " + size;
        return new Inventory(new Item(description, price, calories), 0); // Change the quantity as required
    }

    private Inventory createIce() {
        double price = 5.0;
        int calories = 0;
        String description = "Ice";
        return new Inventory(new Item(description, price, calories), 0); // Change the quantity as required
    }


    public SpecialVendingMachine createSpecialVendingMachine(Scanner scanner) {
        List<Inventory> inventory = new ArrayList<>();
        Map<Double, Denomination> acceptedCash = new HashMap<>();

        System.out.println("Special Vending Machine created.");
        inventory.add(createWhiteChocolateCoffee());
        inventory.add(createCaramelMacchiato());
        inventory.add(createVanillaSyrup());
        inventory.add(createCups("Small"));
        inventory.add(createCups("Medium"));
        inventory.add(createCups("Large"));
        inventory.add(createIce());

        // Add other items as required (e.g., espresso, sugar, etc.)

        acceptedCash.put(0.10, new Denomination(0.5));
        acceptedCash.put(0.25, new Denomination(0.10));
        acceptedCash.put(0.50, new Denomination(0.75));
        acceptedCash.put(0.75, new Denomination(0.25));
        acceptedCash.put(5.0, new Denomination(5));
        acceptedCash.put(10.0, new Denomination(10));
        acceptedCash.put(20.0, new Denomination(20));
        acceptedCash.put(50.0, new Denomination(50));
        acceptedCash.put(100.0, new Denomination(100));
        acceptedCash.put(500.0, new Denomination(500));

        return new SpecialVendingMachine(inventory, acceptedCash);
    }

    private Inventory createWhiteChocolateCoffee() {
        double price = 85.0;
        int calories = 75;
        String description = "White Chocolate Coffee";

        return new Inventory(new Item(description, price, calories), 0);
    }

    private Inventory createCaramelMacchiato() {
        double price = 80.0;
        int calories = 50;
        String description = "Caramel Macchiato";

        return new Inventory(new Item(description, price, calories), 0);
    }

    private String getProductByChoice(int choice) {
        switch (choice) {
            case 1:
                return "Water";
            case 2:
                return "Iced tea";
            case 3:
                return "Apple juice";
            case 4:
                return "Orange juice";
            case 5:
                return "Grape juice";
            case 6:
                return "Coconut juice";
            case 7:
                return "Lemon juice";
            case 8:
                return "Cow milk";
            case 9:
                return "Coconut Milk";
            case 10:
                return "Matcha";
            case 11:
                return "Soy Milk";
            case 12:
                return "Almond Milk";
            default:
                return null;
        }
    }

    private double getPriceByChoice(int choice) {
        switch (choice) {
            case 1:
                return 20.0;
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
                return 35.0;
            case 7:
                return 40.0;
            case 8:
            case 9:
                return 45.0;
            case 10:
            case 11:
                return 60.0;
            case 12:
                return 75.0;
            default:
                return 0.0;
        }
    }

    private int getCaloriesByChoice(int choice) {
        switch (choice) {
            case 1:
                return 0;
            case 2:
                return 95;
            case 3:
            case 4:
                return 118;
            case 5:
                return 161;
            case 6:
                return 48;
            case 7:
                return 59;
            case 8:
                return 109;
            case 9:
                return 575;
            case 10:
                return 68;
            case 11:
                return 135;
            case 12:
                return 43;
            default:
                return 0;
        }
    }
}
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class SVMGUI extends JFrame {
    private SpecialVendingMachine vendingMachine;
    private JTextArea outputTextArea;
    private JTextField amountPaidTextField;
    private JComboBox<String> drinkComboBox;
    private JComboBox<String> cupSizeComboBox;
    private JComboBox<String> temperatureComboBox;
    private JComboBox<String> sugarLevelComboBox;
    private JComboBox<String> milkChoiceComboBox;
    private JCheckBox numEspressoCheckBox;
    private JButton purchaseButton;
    private JPanel mainPanel;

    public SVMGUI(SpecialVendingMachine vendingMachine) {
        this.vendingMachine = vendingMachine;
        setTitle("Special Vending Machine");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        initComponents();
        pack();
        setLocationRelativeTo(null);

        initializeComboBoxes();
        setupListeners();
    }

    private void initComponents() {
        mainPanel = new JPanel(new BorderLayout());
        setContentPane(mainPanel);

        // Create the Test Features and Maintenance panels
        JPanel testFeaturesPanel = createTestFeaturesPanel();
        JPanel maintenanceFeaturesPanel = createMaintenanceFeaturesPanel();

        // Create a tabbed pane to switch between Test Features and Maintenance menu
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Test Vending Features", testFeaturesPanel);
        tabbedPane.addTab("Maintenance Menu", maintenanceFeaturesPanel);

        mainPanel.add(tabbedPane, BorderLayout.CENTER);

        // Create the output text area
        outputTextArea = new JTextArea(10, 30);
        outputTextArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputTextArea);
        mainPanel.add(scrollPane, BorderLayout.SOUTH);
    }

    private void initializeComboBoxes() {
        String[] drinkOptions = {
            "Select a Drink",
            "White Chocolate Coffee",
            "Caramel Macchiato"
        };
        drinkComboBox = new JComboBox<>(drinkOptions);

        String[] cupSizeOptions = {
            "Small",
            "Medium",
            "Large"
        };
        cupSizeComboBox = new JComboBox<>(cupSizeOptions);

        String[] temperatureOptions = {
            "Hot",
            "Iced"
        };
        temperatureComboBox = new JComboBox<>(temperatureOptions);

        String[] sugarLevelOptions = {
            "No Sugar",
            "With Sugar",
        };
        sugarLevelComboBox = new JComboBox<>(sugarLevelOptions);

        String[] milkChoiceOptions = {
            "Cow Milk",
            "Soy Milk",
            "Almond Milk"
        };
        milkChoiceComboBox = new JComboBox<>(milkChoiceOptions);

        numEspressoCheckBox = new JCheckBox("Add Espresso Shots");
    }

    private JPanel createTestFeaturesPanel() {
        // Test Vending Machine Features GUI
        String[] vendingFeaturesOptions = {
                "Purchase Item",
                "Return to Main Menu"
        };
        JComboBox<String> vendingFeaturesComboBox = new JComboBox<>(vendingFeaturesOptions);

        purchaseButton = new JButton("Execute");

        purchaseButton.addActionListener(e -> {
            int choice = vendingFeaturesComboBox.getSelectedIndex();

            switch (choice) {
                case 0:
                    // Purchase Item
                    purchaseItem();
                    break;
                case 1:
                    // Return to Main Menu
                    initComponents();
                    break;
                default:
                    // Invalid choice
                    break;
            }
        });

        JPanel testVendingFeaturesPanel = new JPanel();
        testVendingFeaturesPanel.add(new JLabel("Test Vending Machine Features:"));
        testVendingFeaturesPanel.add(vendingFeaturesComboBox);
        testVendingFeaturesPanel.add(purchaseButton);

        return testVendingFeaturesPanel;
    }

    private JPanel createMaintenanceFeaturesPanel() {
        // Maintenance Menu GUI
        String[] maintenanceOptions = {
                "Restock Items",
                "Add Money For Change",
                "Print Transaction Summary",
                "Collect Payment",
                "Make Change",
                "Set Item Price",
                "Return to Test a Vending Machine Menu"
        };
        JComboBox<String> maintenanceComboBox = new JComboBox<>(maintenanceOptions);

        JButton maintenanceButton = new JButton("Execute");

        maintenanceButton.addActionListener(e -> {
            int choice = maintenanceComboBox.getSelectedIndex();

            switch (choice) {
                case 0:
                    // Restock Items
                    restockItems();
                    break;
                case 1:
                    // Add Money For Change
                    addMoneyForChange();
                    break;
                case 2:
                    // Print Transaction Summary
                    printTransactionSummary();
                    break;
                case 3:
                    // Collect Payment
                    collectPayment();
                    break;
                case 4:
                    // Make Change
                    addMoneyForChange();
                    break;
                case 5:
                    // Make Change
                    setItemPrice();
                    break;
                case 6:
                    // Return to Test a Vending Machine Menu
                    initComponents();
                    break;
                default:
                    // Invalid choice
                    break;
            }
        });

        JPanel maintenancePanel = new JPanel();
        maintenancePanel.add(new JLabel("Maintenance Menu:"));
        maintenancePanel.add(maintenanceComboBox);
        maintenancePanel.add(maintenanceButton);

        return maintenancePanel;
    }

    private void setupListeners() {
        purchaseButton.addActionListener(e -> handlePurchaseButton());
    }

    private CustomDrink createCustomDrink() {
        String drinkName = getDrinkNameByChoice(drinkComboBox.getSelectedIndex());
        String cupSize = (String) cupSizeComboBox.getSelectedItem();
        String temperature = (String) temperatureComboBox.getSelectedItem();
        String sugarLevel = (String) sugarLevelComboBox.getSelectedItem();
        String milkChoice = (String) milkChoiceComboBox.getSelectedItem();

        CustomDrink customDrink = new CustomDrink(drinkName);
        customDrink.setCupSize(cupSize);
        customDrink.setTemperature(temperature);
        customDrink.setSugarLevel(sugarLevel);
        customDrink.setMilkChoice(milkChoice);

        return customDrink;
    }

    private void handlePurchaseButton() {
        String amountPaidStr = amountPaidTextField.getText();
        double amountPaid;
        try {
            amountPaid = Double.parseDouble(amountPaidStr);
        } catch (NumberFormatException ex) {
            outputTextArea.append("Invalid amount. Please enter a valid number.\n");
            return;
        }

        int drinkChoice = drinkComboBox.getSelectedIndex();
        if (drinkChoice <= 0) {
            outputTextArea.append("Please select a drink.\n");
            return;
        }

        CustomDrink customDrink = createCustomDrink();

        int numEspressoShots = numEspressoCheckBox.isSelected() ? 1 : 0;
        customDrink.setNumEspressoShots(numEspressoShots);

        int totalCalories = vendingMachine.calculateTotalCalories(customDrink);
        double totalPrice = vendingMachine.calculateTotalPrice(customDrink);

        if (amountPaid < totalPrice) {
            outputTextArea.append("Insufficient payment. Purchase canceled.\n");
            return;
        }

        int result = JOptionPane.showConfirmDialog(this, getOrderSummary(customDrink, totalCalories, totalPrice) + "Confirm purchase?", "Confirm Purchase", JOptionPane.YES_NO_OPTION);
        if (result == JOptionPane.YES_OPTION) {
            vendingMachine.prepareDrink(customDrink);
            outputTextArea.append("Drink prepared and purchased successfully.\n");

            double change = amountPaid - totalPrice;
            outputTextArea.append("Change: Php " + change + "\n");
            outputTextArea.append("Thank you for your purchase!\n");
        } else {
            outputTextArea.append("Purchase canceled.\n");
        }
    }

    private String getDrinkNameByChoice(int choice) {
        switch (choice) {
            case 1:
                return "White Chocolate Coffee";
            case 2:
                return "Caramel Macchiato";
            default:
                return null;
        }
    }

    private String getOrderSummary(CustomDrink customDrink, int totalCalories, double totalPrice) {
        String orderSummary = "Order Summary:\n";
        orderSummary += "Customizations:\n";
        orderSummary += "Cup Size: " + customDrink.getCupSize() + "\n";
        orderSummary += "Temperature: " + customDrink.getTemperature() + "\n";
        orderSummary += "Sugar Level: " + customDrink.getSugarLevel() + "\n";
        orderSummary += "Milk Choice: " + customDrink.getMilkChoice() + "\n";
        orderSummary += "Espresso Shots: " + customDrink.getNumEspressoShots() + " (Hot) / " + customDrink.getNumEspressoShots() + " (Iced)\n";
        orderSummary += "Total Calories: " + totalCalories + "\n";
        orderSummary += "Total Price: Php " + totalPrice + "\n";
        return orderSummary;
    }

    private void restockItems() {
        // Restock Items GUI
        String[] restockOptions = { "Restock Items", "Return to Maintenance Menu" };
        JComboBox<String> restockComboBox = new JComboBox<>(restockOptions);

        JButton restockButton = new JButton("Execute");

        restockButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int choice = restockComboBox.getSelectedIndex();

                switch (choice) {
                    case 0:
                        // Restock Items
                        restockItems();
                        break;
                    case 1:
                        // Return to Maintenance Menu
                        createMaintenanceFeaturesPanel();
                        break;
                    default:
                        // Invalid choice
                        break;
                }
            }
        });

        JPanel restockPanel = new JPanel();
        restockPanel.add(new JLabel("Restock Items:"));
        restockPanel.add(restockComboBox);
        restockPanel.add(restockButton);

        // Update the main panel to show the restock panel
        mainPanel.removeAll();
        mainPanel.add(restockPanel);
        mainPanel.revalidate();
        mainPanel.repaint();
    }

    private void setItemPrice() {
        // Set Item Price GUI
        String[] priceOptions = { "Set Item Price", "Return to Maintenance Menu" };
        JComboBox<String> priceComboBox = new JComboBox<>(priceOptions);

        JButton priceButton = new JButton("Execute");

        priceButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int choice = priceComboBox.getSelectedIndex();

                switch (choice) {
                    case 0:
                        // Set Item Price
                        setItemPrice();
                        break;
                    case 1:
                        // Return to Maintenance Menu
                        createMaintenanceFeaturesPanel();
                        break;
                    default:
                        // Invalid choice
                        break;
                }
            }
        });

        JPanel pricePanel = new JPanel();
        pricePanel.add(new JLabel("Set Item Price:"));
        pricePanel.add(priceComboBox);
        pricePanel.add(priceButton);

        // Update the main panel to show the price panel
        mainPanel.removeAll();
        mainPanel.add(pricePanel);
        mainPanel.revalidate();
        mainPanel.repaint();
    }

    private void collectPayment() {
        // Collect Payment GUI
        String[] paymentOptions = { "Collect Payment", "Return to Maintenance Menu" };
        JComboBox<String> paymentComboBox = new JComboBox<>(paymentOptions);

        JButton paymentButton = new JButton("Execute");

        paymentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int choice = paymentComboBox.getSelectedIndex();

                switch (choice) {
                    case 0:
                        // Collect Payment
                        collectPayment();
                        break;
                    case 1:
                        // Return to Maintenance Menu
                        createMaintenanceFeaturesPanel();
                        break;
                    default:
                        // Invalid choice
                        break;
                }
            }
        });

        JPanel paymentPanel = new JPanel();
        paymentPanel.add(new JLabel("Collect Payment:"));
        paymentPanel.add(paymentComboBox);
        paymentPanel.add(paymentButton);

        // Update the main panel to show the payment panel
        mainPanel.removeAll();
        mainPanel.add(paymentPanel);
        mainPanel.revalidate();
        mainPanel.repaint();
    }

    private void addMoneyForChange() {
        // Add Money For Change GUI
        String[] addMoneyOptions = { "Add Money For Change", "Return to Maintenance Menu" };
        JComboBox<String> addMoneyComboBox = new JComboBox<>(addMoneyOptions);

        JButton addMoneyButton = new JButton("Execute");

        addMoneyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int choice = addMoneyComboBox.getSelectedIndex();

                switch (choice) {
                    case 0:
                        // Add Money For Change
                        addMoneyForChange();
                        break;
                    case 1:
                        // Return to Maintenance Menu
                        createTestFeaturesPanel();
                        break;
                    default:
                        // Invalid choice
                        break;
                }
            }
        });

        JPanel addMoneyPanel = new JPanel();
        addMoneyPanel.add(new JLabel("Add Money For Change:"));
        addMoneyPanel.add(addMoneyComboBox);
        addMoneyPanel.add(addMoneyButton);

        // Update the main panel to show the add money panel
        mainPanel.removeAll();
        mainPanel.add(addMoneyPanel);
        mainPanel.revalidate();
        mainPanel.repaint();
    }

    private void purchaseItem() {
        // Purchase Item GUI
        String[] purchaseOptions = { "Purchase Item", "Return to Vending Machine Test Menu" };
        JComboBox<String> purchaseComboBox = new JComboBox<>(purchaseOptions);
    
        JButton executeButton = new JButton("Execute");
    
        executeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int choice = purchaseComboBox.getSelectedIndex();
    
                switch (choice) {
                    case 0:
                        // Purchase Item
                        purchaseItem();
                        break;
                    case 1:
                        // Return to Vending Machine Test Menu
                        createTestFeaturesPanel();
                        break;
                    default:
                        // Invalid choice
                        break;
                }
            }
        });
    
        JPanel purchasePanel = new JPanel();
        purchasePanel.add(new JLabel("Purchase Item:"));
        purchasePanel.add(purchaseComboBox);
        purchasePanel.add(executeButton);
    
        // Update the main panel to show the purchase panel
        mainPanel.removeAll();
        mainPanel.add(purchasePanel);
        mainPanel.revalidate();
        mainPanel.repaint();
    }
    

    public void displayInventory() {
        vendingMachine.displayInventory();
    }

    public void printTransactionSummary() {
        // Calculate the total number of items purchased
        int totalItemsPurchased = 0;
        double totalSalesAmount = 0;
        List<Inventory> invList = vendingMachine.getInventory();

        // Now you can use the invList to access and manipulate the inv list
        for (Inventory itemInventory : invList)  {
            totalItemsPurchased += itemInventory.getQuantity();
            totalSalesAmount += itemInventory.getItem().getPrice() * itemInventory.getQuantity();
        }

        // Create the transaction summary message
        String message = "Transaction Summary:\n";
        message += "Total Items Purchased: " + totalItemsPurchased + "\n";
        message += "Total Sales Amount: Php " + String.format("%.2f", totalSalesAmount) + "\n";

        // Display the message box with the transaction summary
        JOptionPane.showMessageDialog(null, message, "Transaction Summary", JOptionPane.INFORMATION_MESSAGE);
    }
    
}

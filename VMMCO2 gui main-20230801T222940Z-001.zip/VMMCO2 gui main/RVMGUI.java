import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Map;

public class RVMGUI extends JFrame {
    private RegularVendingMachine vendingMachine;

    public RVMGUI(RegularVendingMachine vendingMachine) {
        this.vendingMachine = vendingMachine;
        setTitle("Regular Vending Machine");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        initComponents();
        pack();
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        setContentPane(mainPanel);

        // Create the Test Features and Maintenance panels
        JPanel testFeaturesPanel = createTestFeaturesPanel();
        JPanel maintenanceFeaturesPanel = createMaintenanceFeaturesPanel();

        // Create a tabbed pane to switch between Test Features and Maintenance menu
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Test Vending Features", testFeaturesPanel);
        tabbedPane.addTab("Maintenance Menu", maintenanceFeaturesPanel);

        mainPanel.add(tabbedPane, BorderLayout.CENTER);
    }

    // Method to create the panel for Test Features
    private JPanel createTestFeaturesPanel() {
        JPanel testPanel = new JPanel(new BorderLayout());

        // A text area to display output to the user
        JTextArea outputTextArea = new JTextArea(10, 30);
        outputTextArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputTextArea);
        testPanel.add(scrollPane, BorderLayout.CENTER);

        // Button for simulating purchasing an item
        JButton purchaseButton = new JButton("Purchase Item");
        purchaseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                purchaseItem(outputTextArea);
            }
        });

        testPanel.add(purchaseButton, BorderLayout.SOUTH);

        return testPanel;
    }

    private JPanel createMaintenanceFeaturesPanel() {
        JPanel maintenancePanel = new JPanel(new BorderLayout());

        JTextArea outputTextArea = new JTextArea(10, 30);
        outputTextArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputTextArea);
        maintenancePanel.add(scrollPane, BorderLayout.CENTER);

        JButton restockButton = new JButton("Restock Items");
        restockButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String result = restockItems(outputTextArea);
                outputTextArea.append(result);
            }
        });

        JButton setPriceButton = new JButton("Set Item Price");
        setPriceButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setItemPrice(outputTextArea);
            }
        });

        JButton collectPaymentButton = new JButton("Collect Payment");
        collectPaymentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                collectPayment(outputTextArea);
            }
        });

        JButton makeChangeButton = new JButton("Make Change");
        makeChangeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                makeChange(outputTextArea);
            }
        });

        JButton printTransactionHistoryButton = new JButton("Print Transaction History");
        printTransactionHistoryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                printTransactionHistory(outputTextArea);
            }
        });

        JPanel buttonPanel = new JPanel(new GridLayout(2, 2));
        buttonPanel.add(restockButton);
        buttonPanel.add(setPriceButton);
        buttonPanel.add(collectPaymentButton);
        buttonPanel.add(makeChangeButton);
        buttonPanel.add(printTransactionHistoryButton);

        maintenancePanel.add(buttonPanel, BorderLayout.SOUTH);

        return maintenancePanel;
    }

    private String restockItems(JTextArea outputTextArea) {
        StringBuilder restockOutput = new StringBuilder();

        restockOutput.append("Restocking items:\n");
        restockOutput.append("Enter the quantity to restock for each item:\n");

        for (Inventory itemInventory : vendingMachine.getInventory()) {
            String itemName = itemInventory.getItem().getName();
            int currentQuantity = itemInventory.getQuantity();
            int maxCapacity = 15;
            int remainingCapacity = maxCapacity - currentQuantity;

            String input = JOptionPane.showInputDialog("Enter the quantity to restock for " + itemName +
                    " (Remaining capacity: " + remainingCapacity + "): ");

            try {
                int quantity = Integer.parseInt(input);
                if (quantity < 10 || quantity > 15) {
                    restockOutput.append("Invalid input! Please enter a quantity between 10 and 15: " + input + "\n");
                } else {
                    int actualRestockQuantity = Math.min(quantity, remainingCapacity);
                    itemInventory.addItem(actualRestockQuantity);
                    restockOutput.append(actualRestockQuantity + " pieces of " + itemName + " restocked.\n");
                }
            } catch (NumberFormatException e) {
                restockOutput.append("Invalid input! Please enter a valid number.\n");
            }
        }

        restockOutput.append("Items restocked successfully.\n");

        return restockOutput.toString();
    }

    private void setItemPrice(JTextArea outputTextArea) {
        String slotNumberInput = JOptionPane.showInputDialog("Enter the slot number to set the price: ");
        try {
            int slotNumber = Integer.parseInt(slotNumberInput);
            if (slotNumber >= 1 && slotNumber <= vendingMachine.getInventory().size()) {
                int selectedIndex = slotNumber - 1;
                Inventory selectedInventory = vendingMachine.getInventory().get(selectedIndex);
                Item item = selectedInventory.getItem();

                String newPriceInput = JOptionPane.showInputDialog("Enter the new price for " + item.getName() + ": ");
                try {
                    double newPrice = Double.parseDouble(newPriceInput);
                    item.setPrice(newPrice);
                    outputTextArea.append("Price for " + item.getName() + " updated successfully.\n");
                } catch (NumberFormatException e) {
                    outputTextArea.append("Invalid input! Please enter a valid price.\n");
                }
            } else {
                outputTextArea.append("Invalid slot number.\n");
            }
        } catch (NumberFormatException e) {
            outputTextArea.append("Invalid input! Please enter a valid number.\n");
        }
    }

    private void collectPayment(JTextArea outputTextArea) {
        outputTextArea.append("Collecting payment...\n");
        // Perform the payment collection logic for the regular vending machine
        outputTextArea.append("Payment collected successfully.\n");
    }

    private void purchaseItem(JTextArea outputTextArea) {
        String amountPaidInput = JOptionPane.showInputDialog("Enter the amount to pay (or 0 to cancel): ");
        try {
            double amountPaid = Double.parseDouble(amountPaidInput);
            if (amountPaid == 0) {
                outputTextArea.append("Purchase canceled.\n");
                return;
            }

            outputTextArea.append("\nAvailable Items:\n");
            displayInventory(outputTextArea);

            String slotNumberInput = JOptionPane.showInputDialog("Enter the slot number to purchase the item: ");
            try {
                int slotNumber = Integer.parseInt(slotNumberInput);
                if (slotNumber >= 1 && slotNumber <= vendingMachine.getInventory().size()) {
                    int selectedIndex = slotNumber - 1;
                    Inventory selectedInventory = vendingMachine.getInventory().get(selectedIndex);
                    Item item = selectedInventory.getItem();

                    if (selectedInventory.getQuantity() > 0) {
                        outputTextArea.append("Selected item: " + item.getName() + "\n");
                        outputTextArea.append("Price: " + item.getPrice() + "\n");
                        outputTextArea.append("Calories: " + item.getCalories() + "\n");

                        if (amountPaid >= item.getPrice()) {
                            double change = amountPaid - item.getPrice();
                            if (vendingMachine.hasSufficientChange(change)) {
                                selectedInventory.removeItem(1);
                                vendingMachine.addToSales(item.getPrice());
                                outputTextArea.append("Item purchased successfully.\n");
                                outputTextArea.append("Change: " + change + "\n");
                                outputTextArea.append("Dispensing Item: " + item.getName() + "\n");
                                outputTextArea.append("Dispensing change with the following denominations...\n");
                                vendingMachine.produceChange(change);
                            } else {
                                outputTextArea.append("Insufficient change. Please try again later.\n");
                            }
                        } else {
                            outputTextArea.append("Insufficient amount paid. Transaction canceled.\n");
                        }
                    } else {
                        outputTextArea.append("Selected item is out of stock.\n");
                    }
                } else {
                    outputTextArea.append("Invalid slot number.\n");
                }
            } catch (NumberFormatException e) {
                outputTextArea.append("Invalid input! Please enter a valid number for the slot number.\n");
            }
        } catch (NumberFormatException e) {
            outputTextArea.append("Invalid input! Please enter a valid number for the amount.\n");
        }
    }

    private void displayInventory(JTextArea outputTextArea) {
        outputTextArea.append("Slot\tItem Name\tPrice\t\tQuantity\n");
        for (int i = 0; i < vendingMachine.getInventory().size(); i++) {
            Inventory itemInventory = vendingMachine.getInventory().get(i);
            Item item = itemInventory.getItem();
            String itemName = item.getName();
            double itemPrice = item.getPrice();
            int quantity = itemInventory.getQuantity();
            String slotLabel = "[" + (i + 1) + "]";
            String quantityLabel = (quantity > 0) ? String.valueOf(quantity) : "Out of stock";
            outputTextArea.append(String.format("%-8s%-16sPhp%8.2f    %s%n", slotLabel, itemName, itemPrice, quantityLabel));
        }
    }

    private void makeChange(JTextArea outputTextArea) {
        StringBuilder changeOutput = new StringBuilder();

        changeOutput.append("Change refill:\n");

        for (Map.Entry<Double, Denomination> entry : vendingMachine.getAcceptedCash().entrySet()) {
            changeOutput.append("Enter the quantity to refill for Php" + entry.getKey() + ": ");
            String input = JOptionPane.showInputDialog(this, changeOutput.toString());

            try {
                int quantity = Integer.parseInt(input);
                if (quantity < 0) {
                    JOptionPane.showMessageDialog(this, "Invalid input! Please enter a positive quantity.");
                } else {
                    entry.getValue().setQuantity(entry.getValue().getQuantity() + quantity);
                    outputTextArea.append("Php" + entry.getKey() + " refill successful.\n");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid input! Please enter a valid number.");
            }

            changeOutput.setLength(0); // Clear the StringBuilder for the next denomination
        }
    }

    private void printTransactionHistory(JTextArea outputTextArea) {
        StringBuilder transactionSummary = new StringBuilder("Transaction Summary:\n");

        for (Item item : vendingMachine.sales) {
            transactionSummary.append("Item: ").append(item.getName()).append(" - Price: ").append(item.getPrice()).append("\n");
        }

        outputTextArea.setText(transactionSummary.toString());
    }
}
